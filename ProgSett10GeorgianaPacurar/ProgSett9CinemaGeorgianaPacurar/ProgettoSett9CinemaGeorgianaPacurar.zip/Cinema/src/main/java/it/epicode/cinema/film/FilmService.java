package it.epicode.cinema.film;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import it.epicode.cinema.Cinema;
import it.epicode.cinema.CinemaRepository;

/**
 * Creazione classe per la gestione
 * del Service in Film 
 * @author Georgiana Pacurar 
 */
@Service
public class FilmService {

	@Autowired
	FilmRepository fr;
	@Autowired
	CinemaRepository cr;
	
	
	/**
	 * 
	 * Inserimento di un film in db
	 * gestito nel service con dto
	 *
	 * @param dto
	 * @return
	 */

	@Operation (summary = "Inserisce un film nel db", description = "Inserisce un film nel db con Regista, titolo, anno film, tipologia film, incasso del film, nome cinema, citta cinema, indirizzo cinema gestito con dto ")
	@ApiResponse (responseCode = "200" , description = "Film inserito con successo nel db")
	@ApiResponse (responseCode = "500" , description = "Errore")
	
	public boolean inserisciFilm (FilmRequestInserisciDTO dto ) {
		
	
		Cinema c = new Cinema();
		Film f = new Film();
		c.setNomeCinema(dto.getNomeCinema());
		c.setCitta(dto.getCitta());
		c.setIndirizzo(dto.getIndirizzo());
		List<Film> lf = new ArrayList();
		c.setLFilm(lf);
		f.setTitoloFilm(dto.getTitoloFilm());
		f.setAnnoFilm(dto.getAnnoFilm());
		f.setTipoFilm(dto.getTipoFilm());
		f.setNomeRegista(dto.getNomeRegista());
		f.setIncassoFilm(dto.getIncassoFilm());
		lf.add(f);
		
		fr.save(f);
		cr.save(c);
		
		return true;
	}
	
	/**
	 * 
	 * Modifica della tipologia di un film
	 * gestita nel service con dto
	 * @param id
	 * @param dto
	 * @return tipo film modificato
	 */

	@Operation (summary = "Modifica un film nel db", description = "Modifica la tipologia di un film nel db gestito con dto ")
	@ApiResponse (responseCode = "200" , description = "Film modificato con successo nel db")
	@ApiResponse (responseCode = "500" , description = "Errore")

	public boolean modificaFilm (int id, FilmRequestModificaDTO dto) {
		if (!fr.existsById(id)) {
			return false;
		}
		Film f = fr.findById(id).get();
		f.setTipoFilm(dto.getTipoFilm());
		f.setAnnoFilm(dto.getAnnoFilm());
		f.setIncassoFilm(dto.getIncassoFilm());
		f.setNomeRegista(dto.getNomeRegista());
		f.setTitoloFilm(dto.getTitoloFilm());
		fr.save(f);
	
		return true;
	
	
		
	}
		
	}

