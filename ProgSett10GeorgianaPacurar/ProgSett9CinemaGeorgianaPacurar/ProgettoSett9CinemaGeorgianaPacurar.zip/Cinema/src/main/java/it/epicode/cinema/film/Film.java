package it.epicode.cinema.film;

import javax.persistence.CascadeType;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import it.epicode.cinema.Cinema;
import it.epicode.cinema.film.Film;
import it.epicode.cinema.Cinema;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Crezione classe Film con relativi attributi
 * Gestisce la persistenza sul db
 * Utilizzo di lombok
 * @author Georgiana Pacurar
 * 
 */

@Entity
@Data
@NoArgsConstructor
public class Film {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	private int id;
	@NotBlank(message = "Il Nome del regista è obbligatorio")
	@Size(min = 3, max = 30, message = "Deve essere di min 5 caratteri e max 30 caratteri")
	private String nomeRegista;
	@NotBlank(message = "Il Titolo del film è obbligatorio")
	@Size(min = 2, max = 30, message = "Deve essere di min 2 caratteri e max 30 caratteri")
	private String titoloFilm;
	@NotBlank(message = "L'anno del film è obbligatorio")
	@Size(min = 4, max = 4, message = "Deve essere di min 4 caratteri e max d4 caratteri")
	private String annoFilm;
	@NotBlank(message = "La tipologia del film è obbligatoria")
    private String tipoFilm;
	@NotBlank(message = "L'incasso del film è obbligatorio")
	private String incassoFilm;
	@JoinColumn(name="id_cinema")
	@ManyToOne(cascade = CascadeType.ALL)
    private Cinema cinema;
	
	
}
