package it.epicode.cinema.film;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import it.epicode.cinema.CinemaRepository;




/**
 * Servizi rest relativi alla classe Film
 * @author Georgiana Pacurar
 * 
 */
@Service
@RestController
@RequestMapping("/film")
@Tag(name = "film rest servicies", description = "implementazioni delle api rest dei film")

public class FilmController {
	
	@Autowired
	FilmRepository fr;
	@Autowired
	FilmService fs;
	@Autowired
	CinemaRepository cr;
	


	
	
	
	

	/**
	 * Inserimento a database di un film
	 * Associato al metodo Post
	 * @param f
	 * @return 
	 */
	
	@Operation (summary = "Inserisce un film nel db", description = "Inserisce un film nel db con Regista, titolo, anno film, tipologia film, incasso del film ")
	@ApiResponse (responseCode = "200" , description = "Film inserito con successo nel db")
	@ApiResponse (responseCode = "500" , description = "Errore")
	
	@PostMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	
	public ResponseEntity inserisciFilm (@Valid @RequestBody FilmRequestInserisciDTO dto , BindingResult errori) { 
		if(errori.hasErrors()) {
		
			List<String> descrizioneDiErrore = new ArrayList<String>();
			for(ObjectError e : errori.getAllErrors()) {
			    descrizioneDiErrore.add(e.getDefaultMessage());
				}
			return new ResponseEntity(descrizioneDiErrore , HttpStatus.BAD_REQUEST);
			
			
		}
		String vc = BCrypt.hashpw(dto.getIncassoFilm(), BCrypt.gensalt());
		dto.setIncassoFilm(vc);
		
		fs.inserisciFilm(dto);
		return ResponseEntity.ok("Film Inserito"); 
	}
	/**
	 * Mostra tutti i film nel db
	 * Associato al metodo Get
	 * 
	 * @return lista di film
	 */
	
    @Operation (summary = "Mostra tutti i film ", description = "Mostra tutti i film presenti")
	@ApiResponse (responseCode = "200" , description = "Lista di tutti i film presenti")
	@ApiResponse (responseCode = "500" , description = "Errore")
	
	@GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity mostraTuttiFilm ()  {
    	
         return ResponseEntity.ok(fr.findAll());

		
	}
    /**
	 * Cancella film dal db
	 * Associato al metodo Delete
	 * @param f
	 * @return 
	 */
    

    @Operation (summary = "Cancella un film", description = "Cancella un film")
	@ApiResponse (responseCode = "200" , description = "Film cancellato con successo")
	@ApiResponse (responseCode = "500" , description = "Errore")
	
    @DeleteMapping("/{id}")
    public ResponseEntity cancellaFilm(@PathVariable ("id") int id ) {
		if(fr.existsById(id)) {
		fr.deleteById(id);
		return ResponseEntity.ok("Film eliminato");}
		else {
			return  new ResponseEntity("Film non trovato ", HttpStatus.NOT_FOUND);
		}
	
	
    }
    /**
     * Cerca film per Regista
     * @param nomeRegista
     * @return  film in base al regista
     */
   @Operation (summary = "Cerca film", description = "Cerca un film per regista")
  	@ApiResponse (responseCode = "200" , description = "Film trovato con successo")
  	@ApiResponse (responseCode = "500" , description = "Errore")
  	
    @GetMapping("/byregista/{regista}")
	public ResponseEntity cercaFilmPerNomeRegista (@PathVariable ("regista") String nomeRegista) {
		List<Film> f = fr.findByNomeRegista(nomeRegista);
		if(f.size() > 0) {
			return ResponseEntity.ok(f);
		}
		return new ResponseEntity("Film non trovato", HttpStatus.NOT_FOUND);
	}
	
    /**
     * Ricerca film per id
     * @param id
     * @return film
     */
    @Operation (summary = "Cerca film", description = "Cerca un film per id")
  	@ApiResponse (responseCode = "200" , description = "Film trovato con successo")
  	@ApiResponse (responseCode = "500" , description = "Errore")
  	
	@GetMapping("/{id}")
  	public ResponseEntity cercaFilmPerId (@PathVariable ("id") int id) {
	try {
		return ResponseEntity.ok(fr.findById(id).orElseThrow());
			} catch (Exception e) {
	   e.printStackTrace();
	}
	return new ResponseEntity("Film non trovato", HttpStatus.NOT_FOUND);
}
    
	/**
	 * 
	 * @param id
	 * @param f
	 * @param errori
	 * @return film modificato
	 */
    @Operation (summary = "Modifica film", description = "Modifica gli attributi di un film come anno, regista, titolo, incasso")
  	@ApiResponse (responseCode = "200" , description = "Film modificato con successo")
  	@ApiResponse (responseCode = "500" , description = "Errore")
  	
	@PutMapping("/modificafilm/{id}")
	public ResponseEntity modificaFilm (@Valid @PathVariable("id") int id, @RequestBody FilmRequestModificaDTO dto, BindingResult errori) { 
		if (errori.hasErrors()) {
			List<String> descrizioneDiErrore = new ArrayList<String>();
			for(ObjectError e : errori.getAllErrors()) {
				descrizioneDiErrore.add(e.getDefaultMessage());
			}
			return new ResponseEntity(descrizioneDiErrore , HttpStatus.BAD_REQUEST);
		}
		if (fs.modificaFilm(id, dto)) {
			
			return ResponseEntity.ok("Film modificato");
		}
		else {
	
		return   new ResponseEntity("Film non esistente", HttpStatus.NOT_FOUND);
	}
}
    
}	










