package it.epicode.cinema.film;

import javax.persistence.JoinColumn;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Classe che gestisce le Request DTO 
 * del metodo inserisci
 * @author Georgiana Pacurar
 */

@Data
@NoArgsConstructor
public class FilmRequestInserisciDTO {

	@NotBlank(message = "Il Nome del regista è obbligatorio")
	@Size(min = 3, max = 30, message = "Deve essere di min 5 caratteri e max 30 caratteri")
	private String nomeRegista;
	@NotBlank(message = "Il Titolo del film è obbligatorio")
	@Size(min = 2, max = 30, message = "Deve essere di min 2 caratteri e max 30 caratteri")
	private String titoloFilm;
	@NotBlank(message = "L'anno del film è obbligatorio")
	@Size(min = 4, max = 4, message = "Deve essere di min 4 caratteri e max d4 caratteri")
	private String annoFilm;
	@NotBlank(message = "La tipologia del film è obbligatoria")
    private String tipoFilm;
	@NotBlank(message = "L'incasso del film è obbligatorio")
	private String incassoFilm;
	@NotBlank(message = "Il Nome del cinema è obbligatorio")
	@Size(min = 3, max = 30, message = "Deve essere di min 5 caratteri e max 30 caratteri")
	private String nomeCinema;
	@NotBlank(message = "La città del cinema è obbligatoria")
	@Size(min = 2, max = 30, message = "Deve essere di min 2 caratteri e max 30 caratteri")
	private String citta;
	@NotBlank(message = "L'indirizzo del cinema è obbligatorio")
	@Size(min = 2, max = 30, message = "Deve essere di min 2 caratteri e max 30 caratteri")
	private String indirizzo;
}
