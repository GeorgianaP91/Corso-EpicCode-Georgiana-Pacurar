package it.epicode.cinema;

import org.springframework.data.repository.CrudRepository;

public interface CinemaRepository extends CrudRepository<Cinema, Integer> {

}
