package it.epicode.cinema.film;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;


/**
 * Classe Repository di Film
 * @author Georgiana Pacurar
 * 
 */

public interface FilmRepository extends CrudRepository<Film, Integer> {
	
	/**
	 * Permette di trovare film inserendo il nome del Regista
	 * 
	 * @param nomeRegista
	 * @return una lista di film per Regista
	 */
	
	public List<Film> findByNomeRegista (String nomeRegista);

	public Optional<Film> findAllById(int id);

	
	
	


}
