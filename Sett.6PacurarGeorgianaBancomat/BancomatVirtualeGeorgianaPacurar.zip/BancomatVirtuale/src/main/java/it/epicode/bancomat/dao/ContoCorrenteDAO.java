package it.epicode.bancomat.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import it.epicode.bancomat.data.ConnectionFactory;
import it.epicode.bancomat.data.ContoCorrente;

public class ContoCorrenteDAO {

	
	public boolean esiste (int numero) {
		Connection conn = ConnectionFactory.getConnection();
		PreparedStatement ps = null;
		try {
			 String query = "SELECT * FROM contocorrente WHERE numero = ?";
			 ps = conn.prepareStatement(query);
			 ps.setInt(1, numero);
			 ResultSet result = ps.executeQuery();
			 return result.next();
		} catch (SQLException e) {
			
			System.out.println("Not exist!");
			e.printStackTrace();
		} finally {
			
			try { ps.close(); } catch (SQLException e) { e.printStackTrace(); }
			
			try { conn.close(); } catch (SQLException e) { e.printStackTrace(); }
		}
		System.out.println("Conto non trovato");
		return false;
	
}
	public double infoSaldo (int numero)  {
		Connection conn = ConnectionFactory.getConnection();
		Statement st = null;
		String query = "SELECT saldo FROM contocorrente WHERE numero = " + numero;
	
		try {
			st = conn.createStatement();
			ResultSet result = st.executeQuery(query);
			if (result.next())  {
				return result.getDouble("saldo");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			
			try { st.close(); } catch (SQLException e) { e.printStackTrace(); }
			
			try { conn.close(); } catch (SQLException e) { e.printStackTrace(); }
		}
		return 0;
		
	}	
		
	public boolean preleva(int numeroC, double prelievo)  {
		double saldo = infoSaldo(numeroC);
		Connection conn = ConnectionFactory.getConnection();
		double saldoNuovo = saldo - prelievo;
		int numUpdate = 0;
		String query = "UPDATE contocorrente"
				                   + "SET saldo = " +
				        saldoNuovo
				                   + "WHERE numero = " +
				        numeroC;
				
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(query);
			numUpdate= ps.executeUpdate();
		} catch (SQLException e) {e.printStackTrace();}
		
		finally {
		
        try {conn.close();} catch (SQLException e) { e.printStackTrace();}
		}	
		return numUpdate > 0;
	
	}
	
	public boolean versa(int numeroC, double versamento)  {
		double saldo = infoSaldo(numeroC);
		Connection conn = ConnectionFactory.getConnection();
		double saldoNuovo = saldo + versamento;
		int numUpdate = 0;
		String query = "UPDATE contocorrente"
                                     + "SET saldo = " +
                        saldoNuovo
                                     + "WHERE numero = " +
                        numeroC;
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(query);
			numUpdate = ps.executeUpdate();
		} catch (SQLException e) {e.printStackTrace();}
		
		finally {
			
		}
        try {conn.close();} catch (SQLException e) { e.printStackTrace();}
		
		return numUpdate > 0;
	}
	
	public  ContoCorrente getContoCorrente (int numero) {
		Connection conn = ConnectionFactory.getConnection();
		Statement st = null;
		try {
			st = conn.createStatement();
			String query = "SELECT * FROM contocorrente WHERE numero =" + numero;
			ResultSet result = st.executeQuery(query);
			if (result.next())   {
				String intestatario = result.getString("intestatario");
				double saldo = result.getDouble("saldo");
				ContoCorrente c = new ContoCorrente(numero, intestatario, saldo);
				return c;
			}
			
		} catch (SQLException e) {e.printStackTrace();}
		
          finally {
			
			try { st.close(); } catch (SQLException e) { e.printStackTrace(); }
			try { conn.close(); } catch (SQLException e) { e.printStackTrace(); }
		}
		return null;
	}
		
	
	
	
	
	}
	

	    
	            
     