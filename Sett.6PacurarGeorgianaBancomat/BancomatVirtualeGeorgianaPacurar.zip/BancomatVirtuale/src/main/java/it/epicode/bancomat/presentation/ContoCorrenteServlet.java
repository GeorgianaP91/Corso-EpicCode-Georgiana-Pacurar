package it.epicode.bancomat.presentation;

import jakarta.ejb.EJB;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import it.epicode.bancomat.business.BancomatEJB;

/**
 * Servlet implementation class ContoCorrenteServlet
 */
public class ContoCorrenteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       @EJB
       BancomatEJB bejb;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ContoCorrenteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int numero = Integer.parseInt(request.getParameter("numero"));
		String intestatario = request.getParameter("intestatario");
		double saldo = Float.parseFloat(request.getParameter("saldo"));
		String azione = request.getParameter("azione");
		double quantita = Float.parseFloat(request.getParameter("quantita"));
		String operazione = request.getParameter("operazione");
		boolean ok = false;

	
		String mess = "";
		switch(azione) {
			case "preleva":
				
				ok = bejb.nuovoPreleva(operazione, numero, quantita);
		
				request.setAttribute("prelievo", quantita);
				request.setAttribute("saldo", "Il tuo saldo è " + saldo);
				request.setAttribute("contocorrente", "Il tuo conto: " + intestatario);
				
				request.getServletContext().getRequestDispatcher("/WEB-INF/jsp/preleva.jsp").forward(request, response);
				
				 if(ok)  {
					mess = "Prelievo eseguito con successo";
				}else {
					mess = "Attenzione! Non è possibile eseguire operazione.";
				}
				break;
				
			case "versa":
				ok = bejb.nuovoVersa(operazione, numero, quantita);
				if(ok)  {
					mess = "Versamento eseguito con successo";
				}else {
					mess = "Attenzione! Non è possibile eseguire operazione.";
				}
				break;	
				
			case "infoSaldo":
				bejb.nuovoInfoSaldo(operazione, numero, quantita);
				if(ok)  {
					mess = "Il saldo disponibile é:";
				}else {
					mess = "Attenzione! Non è possibile eseguire operazione.";
				}
				break;		
				
		}
		
		
		
	}
  
}
