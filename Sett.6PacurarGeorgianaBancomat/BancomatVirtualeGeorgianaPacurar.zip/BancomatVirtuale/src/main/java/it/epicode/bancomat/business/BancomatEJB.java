package it.epicode.bancomat.business;

import java.sql.Connection;
import java.sql.Statement;

import it.epicode.bancomat.data.ConnectionFactory;
import it.epicode.bancomat.data.ContoCorrente;
import jakarta.ejb.LocalBean;
import jakarta.ejb.Stateless;
import it.epicode.bancomat.dao.ContoCorrenteDAO;

/**
 * Session Bean implementation class BancomatEJB
 */
@Stateless
@LocalBean
public class BancomatEJB {

	private ContoCorrenteDAO c;

	public BancomatEJB() {}

	public boolean controllaOperazione(String operazione, int numero, double quantita) {
		try {
			if((operazione == "saldo" || operazione == "prelievo" || operazione =="versamento") 
					&& c.esiste(numero) && quantita <= c.infoSaldo(numero)) {
			}
			return true;

		} 
		catch (Exception e) {
			e.printStackTrace();
		}
		return false;

	}
	
	public boolean nuovoEsiste(String operazione, int numero, double quantita) {
    	try {
    	if(controllaOperazione(operazione, numero, quantita) == true){
    	}
		return c.esiste(numero);
    	}
    	catch (Exception e) {
    	e.printStackTrace();
    	}
    	return false;
    }
	
	public boolean nuovoPreleva(String operazione, int numero, double quantita) {
    	try {
    	if(controllaOperazione(operazione, numero, quantita) == true){
    	}
		return c.preleva(numero, quantita);
    	}
    	catch (Exception e) {
    	e.printStackTrace();
    	}
    	return false;
    }
	
	public boolean nuovoVersa(String operazione, int numero, double quantita) {
    	try {
    	if(controllaOperazione(operazione, numero, quantita) == true){
    	}
		return c.versa(numero, quantita);
    	}
    	catch (Exception e) {
    	e.printStackTrace();
    	}
    	return false;
    }
	
	public double nuovoInfoSaldo(String operazione, int numero, double quantita) {
    	try {
    	if(controllaOperazione(operazione, numero, quantita) == true){
    	}
		return c.infoSaldo(numero);
    	}
    	catch (Exception e) {
    	e.printStackTrace();
    	}
		return quantita;
    	
    }
	
	public ContoCorrente nuovoContoCorrente(String operazione, int numero, double quantita) {
    	try {
    	if(controllaOperazione(operazione, numero, quantita) == true){
    	}
		return c.getContoCorrente(numero);
    	}
    	catch (Exception e) {
    	e.printStackTrace();
    	}
		return null;
	
	}

}