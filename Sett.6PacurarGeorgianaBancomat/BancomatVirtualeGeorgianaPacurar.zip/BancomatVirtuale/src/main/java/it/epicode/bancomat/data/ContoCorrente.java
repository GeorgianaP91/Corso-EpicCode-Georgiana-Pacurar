package it.epicode.bancomat.data;

public class ContoCorrente {

	private int numero;
	private String intestatario;
	private double saldo;
	
	
	
	public ContoCorrente(int numero, String intestatario, double saldo) {
        this.numero = numero;
		this.intestatario = intestatario;
		this.saldo = saldo;
	}



	public int getNumero() {
		return numero;
	}



	public void setNumero(int numero) {
		this.numero = numero;
	}



	public String getIntestatario() {
		return intestatario;
	}



	public void setIntestatario(String intestatario) {
		this.intestatario = intestatario;
	}



	public double getSaldo() {return saldo;
	}



	public void setSaldo(double saldo) {this.saldo = saldo;}
	
	
	
}
