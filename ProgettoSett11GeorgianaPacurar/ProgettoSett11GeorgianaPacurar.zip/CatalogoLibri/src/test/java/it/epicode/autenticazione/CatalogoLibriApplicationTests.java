package it.epicode.autenticazione;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatalogoLibriApplicationTests {

	@Test
	void contextLoads() {
	}

}
