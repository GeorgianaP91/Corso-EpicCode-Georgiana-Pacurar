package it.epicode.autenticazione.runners;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import it.epicode.autenticazione.model.Autore;
import it.epicode.autenticazione.model.Categoria;
import it.epicode.autenticazione.model.Libro;
import it.epicode.autenticazione.repository.AutoreRepository;
import it.epicode.autenticazione.repository.CategoriaRepository;
import it.epicode.autenticazione.repository.LibroRepository;
import lombok.extern.slf4j.Slf4j;

/**
 * Creazione classe Libro Runner

 *
 * 
 * @author Georgiana Pacurar
 */
@Component
@Slf4j
	public class LibroRunner implements CommandLineRunner {
		
		@Autowired
		LibroRepository lr;
		@Autowired
		AutoreRepository ar;
		@Autowired
		CategoriaRepository cr;
		
		@Override
		public void run(String... args) throws Exception {
			
			Libro l = Libro.builder().anno(1900).titolo("La noia").prezzo(39).build();
			Autore a = Autore.builder().nome("Georgiana").cognome("Pacurar").build();
			Categoria c = Categoria.builder().nome("Mortale").build();
			
			l.setCategorie(new ArrayList<Categoria>());
			l.setAutori(new ArrayList<Autore>());
			l.getAutori().add(a);
			l.getCategorie().add(c);
			lr.save(l);
			
			log.info("===========================================Libro===================");
			log.info("Libro: " + l.getId_libro()+ " "+ l.getTitolo()+ " " + l.getAnno() + " " + l.getPrezzo() + " " + l.getAutori()+ " " + l.getCategorie());
			
		}
	}

