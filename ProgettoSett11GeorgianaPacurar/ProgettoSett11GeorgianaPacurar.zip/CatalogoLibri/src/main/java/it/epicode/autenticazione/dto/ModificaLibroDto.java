package it.epicode.autenticazione.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Creazione classe Dto del metodo modificaLibro
 * 
 * @author Georgiana Pacurar
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class ModificaLibroDto {

	private int id_libro;
	private String titolo;
	private int anno;
	private double prezzo;
	private int id_autore;
	private int id_categoria;
}
	

