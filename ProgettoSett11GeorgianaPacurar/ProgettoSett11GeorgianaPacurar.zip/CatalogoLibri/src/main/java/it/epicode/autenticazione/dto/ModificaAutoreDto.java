package it.epicode.autenticazione.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
/**
 * Creazione classe Dto del metodo modificaAutore
 * 
 * @author Georgiana Pacurar
 */
@NoArgsConstructor
@Data
public class ModificaAutoreDto {

	private int id_autore;
	private String nome;
	private String cognome;
	private int id_libro;
	private int id_categoria;
}
