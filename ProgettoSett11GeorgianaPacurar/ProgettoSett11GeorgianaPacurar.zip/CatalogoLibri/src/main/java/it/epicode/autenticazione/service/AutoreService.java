package it.epicode.autenticazione.service;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.epicode.autenticazione.dto.InserisciAutoreDto;
import it.epicode.autenticazione.dto.ModificaAutoreDto;
import it.epicode.autenticazione.model.Autore;
import it.epicode.autenticazione.model.Categoria;
import it.epicode.autenticazione.model.Libro;
import it.epicode.autenticazione.repository.AutoreRepository;
import it.epicode.autenticazione.repository.CategoriaRepository;
import it.epicode.autenticazione.repository.LibroRepository;

/**
 * Creazione classe Autore Service
 * 
 * @author Georgiana Pacurar
 */
@Service
public class AutoreService {


	@Autowired
	LibroRepository lr;
	@Autowired
	AutoreRepository ar;
	@Autowired
	CategoriaRepository cr;
	
	public void inserisciAutore(InserisciAutoreDto dto) {
		Autore a = new Autore();
		Libro l = lr.findById(dto.getId_libro()).get();
		BeanUtils.copyProperties(dto, a);
		a.getLibri().add(l);
		ar.save(a);
		
		}
	
		public boolean eliminaAutore(int id_autore) {
		if(!lr.existsById(id_autore) ) {
			return false;
		}
		lr.deleteById(id_autore);
		return true;
	}
	
		public boolean modificaAutore(int id_autore, ModificaAutoreDto dto) {
			if(!ar.existsById(dto.getId_autore()) && lr.existsById(dto.getId_libro())) {
				return false;
			}
			Autore a = new Autore();
			Libro l = lr.findById(dto.getId_libro()).get();
			BeanUtils.copyProperties(dto, a);
			a.getLibri().add(l);
			ar.save(a);
			return true;
		}
	
	public List<Autore> mostraTuttiAutori() {
		return (List<Autore>) ar.findAll();
	}
	public Autore cercaPerIdAutore(int id_autore) {
		if(!ar.existsById(id_autore)) {
			return null;
		}
		return ar.findById(id_autore).get();
	}
}

