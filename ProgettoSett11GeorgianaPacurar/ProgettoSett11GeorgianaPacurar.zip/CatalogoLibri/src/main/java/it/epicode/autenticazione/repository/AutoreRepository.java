package it.epicode.autenticazione.repository;


import org.springframework.data.repository.CrudRepository;

import it.epicode.autenticazione.model.Autore;
/**
 * Creazione classe Autore Repository

 *
 * 
 * @author Georgiana Pacurar
 */

public interface AutoreRepository extends CrudRepository<Autore, Integer>{

}
