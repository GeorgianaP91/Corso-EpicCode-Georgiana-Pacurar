package it.epicode.autenticazione.repository;

import org.springframework.data.repository.CrudRepository;

import it.epicode.autenticazione.model.Libro;

/**
 * Creazione classe Libro Repository
 *
 * 
 * @author Georgiana Pacurar
 */
public interface LibroRepository extends CrudRepository<Libro, Integer> {

}
