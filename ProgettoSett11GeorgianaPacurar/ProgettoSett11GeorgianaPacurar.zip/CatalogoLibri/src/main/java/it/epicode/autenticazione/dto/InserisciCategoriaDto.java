package it.epicode.autenticazione.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Creazione classe Dto del metodo inserisciCategoria
 * 
 * @author Georgiana Pacurar
 */
@NoArgsConstructor
@Data
public class InserisciCategoriaDto {

	private String nome;
	private int id_libro;
}
