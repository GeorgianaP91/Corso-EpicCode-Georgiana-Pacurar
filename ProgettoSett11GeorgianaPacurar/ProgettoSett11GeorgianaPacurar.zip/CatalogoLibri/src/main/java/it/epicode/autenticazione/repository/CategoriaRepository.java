package it.epicode.autenticazione.repository;

import org.springframework.data.repository.CrudRepository;

import it.epicode.autenticazione.model.Categoria;

/**
 * Creazione classe Categoria Repository
 *
 * 
 * @author Georgiana Pacurar
 */
public interface CategoriaRepository extends CrudRepository<Categoria, Integer> {

}
