package it.epicode.autenticazione.errors;

/**
 * Creazione classe per la Gestione errori
 *
 * 
 * @author Georgiana Pacurar
 */
public class AlreadyExists extends Exception{
	public AlreadyExists(String message) {
		super(message);
		
	}
	
	
}