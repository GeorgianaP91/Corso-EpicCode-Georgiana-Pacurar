package it.epicode.autenticazione.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
/**
 * Creazione classe Dto del metodo inserisciAutore
 * 
 * @author Georgiana Pacurar
 */
@NoArgsConstructor
@Data
public class InserisciAutoreDto {

	private int id_libro;
	private int id_categoria;
	private String nome;
	private String cognome;
}
