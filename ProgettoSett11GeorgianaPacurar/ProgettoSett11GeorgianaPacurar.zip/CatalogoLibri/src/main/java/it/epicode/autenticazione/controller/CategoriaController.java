package it.epicode.autenticazione.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.epicode.autenticazione.dto.InserisciCategoriaDto;
import it.epicode.autenticazione.dto.ModificaAutoreDto;
import it.epicode.autenticazione.dto.ModificaCategoriaDto;
import it.epicode.autenticazione.model.Autore;
import it.epicode.autenticazione.model.Categoria;
import it.epicode.autenticazione.service.AutoreService;
import it.epicode.autenticazione.service.CategoriaService;

/**
 * Creazione classe Categoria Controller
 * 
 * @author Georgiana Pacurar
 */
public class CategoriaController {

	

		@Autowired
		CategoriaService cs;
		
		@Operation (summary = "Inserisce una categoria nel db", description = "inserisce una categoria nel db con nome, id_categoria")
		@ApiResponse(responseCode = "200" , description = "Operazione avvenuta con successo!")
		@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
	    @SecurityRequirement(name = "bearerAuth")
		@PreAuthorize("hasRole('ADMIN')")
		public ResponseEntity inserisciAutore (@RequestBody @Valid InserisciCategoriaDto dto) {
			cs.inserisciCategoria(dto);
			return ResponseEntity.ok("Categoria Inserita");
		}
		
		@Operation (summary = "Elimina una categoria dal db", description = "elimina una categoria dal db")
		@ApiResponse(responseCode = "200" , description = "Operazione avvenuta con successo!")
		@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
	  	@DeleteMapping("/{id_categoria}")
		
		public ResponseEntity eliminaCategoria(@PathVariable("id_categoria") int id_categoria) {
			boolean okFindIt = cs.eliminaCategoria(id_categoria);
			if(okFindIt) {
				return ResponseEntity.ok("Categoria eliminata");
				
				}return new ResponseEntity("Categoria non trovata", HttpStatus.NOT_FOUND);
				
		}
		@Operation (summary = "Cerca una categoria per id nel db", description = "cerca un per id una categoria nel db")
		@ApiResponse(responseCode = "200" , description = "Categoria trovata!")
		@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
		@GetMapping("/{id_categoria}")
		public ResponseEntity cercaCategoriaPerId(@PathVariable("id_categoria") int id_categoria) {
			Categoria c = cs.cercaPerIdCategoria(id_categoria);
			if(c == null) {
				return new ResponseEntity("Autore non trovato", HttpStatus.NOT_FOUND);
			}
			return ResponseEntity.ok(c);
		}
		@Operation (summary = "Mostra categorie", description = "Mostra tutte le categorie del db")
		@ApiResponse(responseCode = "200" , description = "Operazione avvenuta con successo!")
		@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
		@GetMapping
		public ResponseEntity mostraTutteCategorie() {
			return ResponseEntity.ok(cs.mostraTutteCategorie());
		}
		@Operation (summary = "Modifica categoria", description = "Modifica una categoria del db")
		@ApiResponse(responseCode = "200" , description = "Operazione avvenuta con successo!")
		@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
		@PutMapping("/{id_categoria}")
		public ResponseEntity modificaCategoria(@PathVariable("id_autore") int id_categoria,@Valid @RequestBody ModificaCategoriaDto dto) {
			boolean bb = cs.modificaCategoria(dto, id_categoria);
			if(bb) {
				return ResponseEntity.ok("Categoria modificata con successo!");
			}return new ResponseEntity("Categoria non esistente o non trovata!", HttpStatus.NOT_FOUND);
	}
	}

