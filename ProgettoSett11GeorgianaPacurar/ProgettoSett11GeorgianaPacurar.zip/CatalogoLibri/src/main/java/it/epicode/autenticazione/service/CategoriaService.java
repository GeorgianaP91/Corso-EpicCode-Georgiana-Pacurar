package it.epicode.autenticazione.service;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.epicode.autenticazione.dto.InserisciCategoriaDto;
import it.epicode.autenticazione.dto.ModificaCategoriaDto;
import it.epicode.autenticazione.model.Categoria;
import it.epicode.autenticazione.model.Libro;
import it.epicode.autenticazione.repository.CategoriaRepository;
import it.epicode.autenticazione.repository.LibroRepository;
/**
 * Creazione classe Categoria Service 
 * 
 * @author Georgiana Pacurar
 */
@Service
public class CategoriaService {
        
	    @Autowired
		LibroRepository lr;
		@Autowired
		CategoriaRepository cr;
		
		
		public void inserisciCategoria (InserisciCategoriaDto dto) {
			
			Categoria c = new Categoria();
			Libro l = lr.findById(dto.getId_libro()).get();
			l.getCategorie().add(c);
			c.getLibri().add(l);
			BeanUtils.copyProperties(dto, c);
			cr.save(c);
		}
			
		
	    public boolean modificaCategoria(ModificaCategoriaDto dto, int id_categoria) {
	        if(!cr.existsById(dto.getId_categoria()) && lr.existsById(dto.getId_libro())) {
	        return false;
	    }
	        Categoria c = new Categoria();
			Libro l = lr.findById(dto.getId_libro()).get();
			l.getCategorie().add(c);
			c.getLibri().add(l);
			BeanUtils.copyProperties(dto, c);
			cr.save(c);
	    return true;
	}    
	    
	    public List<Categoria> mostraTutteCategorie() {
	        return (List<Categoria>) cr.findAll();
	    }
	    
	    
	    public Categoria cercaPerIdCategoria(int id_categoria) {
	        if(!cr.existsById(id_categoria)) {
	            return null;
	        }
	        return cr.findById(id_categoria).get();
	    }
	    
	    
	    public boolean eliminaCategoria(int id_categoria) {
	    	if(!cr.existsById(id_categoria)) {
	    		return false ;
	    	} 
	    	cr.deleteById(id_categoria);
	    	return true;
	    }
	}

