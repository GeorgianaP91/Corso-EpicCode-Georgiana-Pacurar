package it.epicode.autenticazione.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Creazione classe Dto del metodo inserisciLibro
 * 
 * @author Georgiana Pacurar
 */

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class InserisciLibroDto {

	private String titolo;
	private int anno;
	private double prezzo;
	private int id_autore;
	private int id_categoria;
}
