package it.epicode.autenticazione.runners;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import it.epicode.autenticazione.impl.ERole;
import it.epicode.autenticazione.impl.Role;
import it.epicode.autenticazione.impl.RoleRepository;
import it.epicode.autenticazione.impl.User;
import it.epicode.autenticazione.impl.UserRepository;

/**
 * Creazione classe User Runner

 *
 * 
 * @author Georgiana Pacurar
 */
@Component
	public class UserRunner implements CommandLineRunner{
		
		@Autowired
	    UserRepository ur;
	    @Autowired
	    RoleRepository rr;
	    @Autowired
	    PasswordEncoder encoder;
	    
	    @Override
	    public void run(String... args) throws Exception {

	Set hash = new HashSet<Role>();
	Set hash1 = new HashSet<Role>();
	Set<Role> roles = new HashSet<Role>();

	Role admin = Role.builder().roleName(ERole.ROLE_ADMIN).build();
	Role user = Role.builder().roleName(ERole.ROLE_USER).build();

	hash.add(admin);
	hash1.add(user);

	User u = User.builder().username("Georgiana").password(BCrypt.hashpw("segreto", BCrypt.gensalt())).roles(hash).build();
	User u1 = User.builder().username("Guest").password(BCrypt.hashpw("Guest11", BCrypt.gensalt())).roles(hash1).build();

	ur.save(u);
	ur.save(u1);
	    }
	}

		

