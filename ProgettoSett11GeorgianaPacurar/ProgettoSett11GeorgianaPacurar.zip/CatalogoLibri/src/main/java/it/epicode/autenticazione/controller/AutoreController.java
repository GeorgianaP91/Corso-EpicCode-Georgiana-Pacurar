package it.epicode.autenticazione.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.epicode.autenticazione.dto.InserisciAutoreDto;
import it.epicode.autenticazione.dto.InserisciLibroDto;
import it.epicode.autenticazione.dto.ModificaAutoreDto;
import it.epicode.autenticazione.dto.ModificaLibroDto;
import it.epicode.autenticazione.model.Autore;
import it.epicode.autenticazione.model.Libro;
import it.epicode.autenticazione.service.AutoreService;
import it.epicode.autenticazione.service.LibroService;

/**
 * Creazione classe Autore Controller
 * 
 * @author Georgiana Pacurar
 */
public class AutoreController {

	@Autowired
	AutoreService as;
	
	@Operation (summary = "Inserisce un autore nel db", description = "inserisce un autore nel db con nome, id_libro")
	@ApiResponse(responseCode = "200" , description = "Operazione avvenuta con successo!")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
    @SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity inserisciAutore (@RequestBody @Valid InserisciAutoreDto dto) {
		as.inserisciAutore(dto);
		return ResponseEntity.ok("Autore Inserito");
	}
	
	@Operation (summary = "Elimina un autore dal db", description = "elimina un autore dal db")
	@ApiResponse(responseCode = "200" , description = "Operazione avvenuta con successo!")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
  	@DeleteMapping("/{id_autore}")
	
	public ResponseEntity eliminaAutore(@PathVariable("id_autore") int id_autore) {
		boolean okFindIt = as.eliminaAutore(id_autore);
		if(okFindIt) {
			return ResponseEntity.ok("Autore eliminato");
			
			}return new ResponseEntity("Autore non trovato", HttpStatus.NOT_FOUND);
			
	}
	@Operation (summary = "Cerca un autore per id nel db", description = "cerca un per id un autore nel db")
	@ApiResponse(responseCode = "200" , description = "Autore trovato!")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
	@GetMapping("/{id_autore}")
	public ResponseEntity cercaAutorePerId(@PathVariable("id_autore") int id_autore) {
		Autore a = as.cercaPerIdAutore(id_autore);
		if(a == null) {
			return new ResponseEntity("Autore non trovato", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(a);
	}
	@Operation (summary = "Mostra autori", description = "Mostra tutti gli autori del db")
	@ApiResponse(responseCode = "200" , description = "Operazione avvenuta con successo!")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
	@GetMapping
	public ResponseEntity mostraTuttiAutori() {
		return ResponseEntity.ok(as.mostraTuttiAutori());
	}
	@Operation (summary = "Modifica autore", description = "Modifica un autore del db")
	@ApiResponse(responseCode = "200" , description = "Operazione avvenuta con successo!")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
	@PutMapping("/{id_autore}")
	public ResponseEntity modificaAutore(@PathVariable("id_autore") int id_autore,@Valid @RequestBody ModificaAutoreDto dto) {
		boolean bb = as.modificaAutore(id_autore, dto);
		if(bb) {
			return ResponseEntity.ok("Autore modificato con successo!");
		}return new ResponseEntity("Autore non esistente o non trovato!", HttpStatus.NOT_FOUND);
}
}

