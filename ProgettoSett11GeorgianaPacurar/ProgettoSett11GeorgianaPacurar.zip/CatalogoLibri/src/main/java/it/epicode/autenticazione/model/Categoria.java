package it.epicode.autenticazione.model;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;
/**
 * Creazione classe Categoria

 *
 * 
 * @author Georgiana Pacurar
 */
@Entity
@Slf4j
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class Categoria {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Setter(value = AccessLevel.NONE)
	private int id_categoria;
	private String nome;
	@ManyToMany(mappedBy = "categorie", cascade = {CascadeType.PERSIST, CascadeType.MERGE})
	@JsonIgnore
	@ToString.Exclude
	@EqualsAndHashCode.Exclude
	private List<Libro> libri = new ArrayList<Libro>();
	private List<Categoria> categorie = new ArrayList<Categoria>();

	
}
