package it.epicode.autenticazione.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import it.epicode.autenticazione.dto.InserisciLibroDto;
import it.epicode.autenticazione.dto.ModificaLibroDto;
import it.epicode.autenticazione.model.Libro;
import it.epicode.autenticazione.service.LibroService;

/**
 * Creazione classe Libro Controller
 * 
 * @author Georgiana Pacurar
 */
@RestController
@RequestMapping("/libro")
public class LibroController {

	@Autowired
	LibroService ls;
	
	@Operation (summary = "Inserisce un libro nel db", description = "inserisce un libro nel db con titolo, anno di uscita, prezzo, id della categoria e id dell'autore")
	@ApiResponse(responseCode = "200" , description = "Operazione avvenuta con successo!")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
    @SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity inserisciLibro (@RequestBody @Valid InserisciLibroDto dto) {
		ls.inserisciLibro(dto);
		return ResponseEntity.ok("Libro Inserito");
	}
	
	@Operation (summary = "Elimina un libro dal db", description = "elimina un libro dal db con titolo, anno di uscita, prezzo")
	@ApiResponse(responseCode = "200" , description = "Operazione avvenuta con successo!")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
  	@DeleteMapping("/{id_libro}")
	
	public ResponseEntity eliminaLibro(@PathVariable("id_libro") int id_libro) {
		boolean okFindIt = ls.eliminaLibro(id_libro);
		if(okFindIt) {
			return ResponseEntity.ok("Libro eliminato");
			
			}return new ResponseEntity("Libro non trovato", HttpStatus.NOT_FOUND);
			
	}
	@Operation (summary = "Cerca un libro per id nel db", description = "cerca un per id un libro nel db")
	@ApiResponse(responseCode = "200" , description = "Libro trovato!")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
	@GetMapping("/{id_libro}")
	public ResponseEntity cercaLibroPerId(@PathVariable("id_libro") int id_libro) {
		Libro l = ls.cercaPerId(id_libro);
		if(l == null) {
			return new ResponseEntity("Libro non trovato", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(l);
	}
	@Operation (summary = "Mostra libri", description = "Mostra tutti i libri del db")
	@ApiResponse(responseCode = "200" , description = "Operazione avvenuta con successo!")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
	@GetMapping
	public ResponseEntity mostraTuttiLibri() {
		return ResponseEntity.ok(ls.mostraTuttiLibri());
	}
	
	@PutMapping("/{id_libro}")
	public ResponseEntity modificaLibro(@PathVariable("id_libro") int id_libro,@Valid @RequestBody ModificaLibroDto dto) {
		boolean bb = ls.modificaLibro(dto, id_libro);
		if(bb) {
			return ResponseEntity.ok("Libro modificato con successo!");
		}return new ResponseEntity("Libro non esistente o non trovato!", HttpStatus.NOT_FOUND);
}
}