package it.epicode.autenticazione;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CatalogoLibriApplication {

	public static void main(String[] args) {
		SpringApplication.run(CatalogoLibriApplication.class, args);
	}

}
