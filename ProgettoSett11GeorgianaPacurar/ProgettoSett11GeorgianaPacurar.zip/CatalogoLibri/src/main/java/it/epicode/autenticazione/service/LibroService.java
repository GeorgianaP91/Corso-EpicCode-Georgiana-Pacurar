package it.epicode.autenticazione.service;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.epicode.autenticazione.dto.InserisciLibroDto;
import it.epicode.autenticazione.dto.ModificaLibroDto;
import it.epicode.autenticazione.model.Autore;
import it.epicode.autenticazione.model.Categoria;
import it.epicode.autenticazione.model.Libro;
import it.epicode.autenticazione.repository.AutoreRepository;
import it.epicode.autenticazione.repository.CategoriaRepository;
import it.epicode.autenticazione.repository.LibroRepository;
/**
 * Creazione classe LibroService
 *
 * 
 * @author Georgiana Pacurar
 */

@Service
public class LibroService {

	@Autowired
	LibroRepository lr;
	@Autowired
	AutoreRepository ar;
	@Autowired
	CategoriaRepository cr;
	
	public void inserisciLibro (InserisciLibroDto dto) {
		Libro l = new Libro();
		Autore a = ar.findById(dto.getId_autore()).get();
		Categoria c = cr.findById(dto.getId_categoria()).get();
		
		a.getLibri().add(l);
		l.getAutori().add(a);
		c.getCategorie().add(c);
		BeanUtils.copyProperties(dto, l);
		lr.save(l);
	
	}
	
	public boolean eliminaLibro(int id_libro) {
		if(!lr.existsById(id_libro) ) {
			return false;
		}
		lr.deleteById(id_libro);
		return true;
	}
	
	public boolean modificaLibro(ModificaLibroDto dto, int id_libro) {
		if(!lr.existsById(dto.getId_libro()) && ar.existsById(dto.getId_autore()) && cr.existsById(dto.getId_categoria())) {
		return false;
	}
	Libro l = new Libro();
    Categoria c = cr.findById(dto.getId_categoria()).get();
	c.getLibri().add(l);
    Autore a = ar.findById(dto.getId_autore()).get();
    a.getLibri().add(l);
    BeanUtils.copyProperties(dto, l);
    lr.save(l);
    return true;
}	
	public List<Libro> mostraTuttiLibri() {
		return (List<Libro>) lr.findAll();
	}
	public Libro cercaPerId(int id_libro) {
		if(!lr.existsById(id_libro)) {
			return null;
		}
		return lr.findById(id_libro).get();
	}
}