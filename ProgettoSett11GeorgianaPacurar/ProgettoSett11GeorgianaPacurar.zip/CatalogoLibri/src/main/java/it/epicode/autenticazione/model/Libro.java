package it.epicode.autenticazione.model;

/**
 * Creazione classe Libro
 *
 * 
 * @author Georgiana Pacurar
 */
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

@Entity
@Slf4j
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Builder
public class Libro {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Setter(value = AccessLevel.NONE)
	private int id_libro;
	private String titolo;
	private int anno;
	private double prezzo;
	private Libro libro;
	@ManyToMany(fetch = FetchType.EAGER, cascade = {CascadeType.PERSIST, CascadeType.MERGE})
	@JoinTable(name ="libri_autori", joinColumns = @JoinColumn(name = "id_libro"), inverseJoinColumns = @JoinColumn(name = "id_autore")) 
	@ToString.Exclude
	@EqualsAndHashCode.Exclude
	private List<Autore> autori = new ArrayList();
	@ManyToMany
	@JoinTable(name = "libri", joinColumns = @JoinColumn(name = "id_libro"), inverseJoinColumns = @JoinColumn(name= "id_categoria"))
	@ToString.Exclude
	@EqualsAndHashCode.Exclude
	private List<Categoria> categorie = new ArrayList();
}

