package it.epicode.autenticazione.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
/**
 * Creazione classe Dto del metodo modificaCategoria
 * 
 * @author Georgiana Pacurar
 */
@NoArgsConstructor
@Data
public class ModificaCategoriaDto {

	private int id_categoria;
	private int id_libro;
	private String nome;
}
