package it.epicode.autenticazione.errors;
import org.springframework.http.HttpStatus;



import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * Creazione classe per la Gestione errori
 *
 * 
 * @author Georgiana Pacurar
 */
@ControllerAdvice

public class GestioneErroriCentralizzata extends ResponseEntityExceptionHandler{
	
	@ExceptionHandler(AlreadyExists.class)
	protected ResponseEntity entitaGiaEsistente(AlreadyExists ex) {
		
		
		
		return new ResponseEntity(ex.getMessage(), HttpStatus.ALREADY_REPORTED);
		
		
	}
	@ExceptionHandler(NotFoundException.class)
	protected ResponseEntity entitaNonTrovata(NotFoundException nt) {
		
		return new ResponseEntity(nt.getMessage(), HttpStatus.NOT_FOUND);
	}
	
}