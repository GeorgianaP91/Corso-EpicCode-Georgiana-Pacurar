package it.epicode.autenticazione.errors;

/**
 * Creazione classe per la Gestione errori
 *
 * 
 * @author Georgiana Pacurar
 */
public class NotFoundException extends Exception{
	public NotFoundException(String message) {
		super(message);
		
	}
	
	
}