package scuola;

public class Voti {

}
