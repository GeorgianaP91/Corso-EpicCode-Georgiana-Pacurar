package scuola;

import java.util.ArrayList;

public class Main {

Studenti studenti1 = new Studenti ("Anna", "Frank", 'F');
Studenti studenti2 = new Studenti ("Paolo", "Bonolis", 'M');
Studenti studenti3 = new Studenti ("Clara", "Rossi", 'F');
Studenti studenti4 = new Studenti ("Heidi", "Neve", 'F');
Studenti studenti5 = new Studenti ("Brad", "Pitt", 'M');

Studenti studenti6 = new Studenti ("Roby", "Facchinetti", 'M');
Studenti studenti7 = new Studenti ("Axel", "Rose", 'M');
Studenti studenti8 = new Studenti ("John", "Lennon", 'M');
Studenti studente9 = new Studenti ("Amelia", "Pizzo", 'F');
Studenti studenti10 = new Studenti ("Raffaella", "Carrà", 'F');

ArrayList<Studenti> scuola1 = new ArrayList<>();
ArrayList<Studenti> scuola2 = new ArrayList<>();

 






	
	
}
