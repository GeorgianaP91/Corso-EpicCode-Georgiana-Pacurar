package scuola;

import java.util.Arrays;

public class Scuola {

Studenti [] studenti;


	
	
}
