package scuola;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class Studenti {
 
	//attributi

	private static int idTot = 1;
	{
		idTot++;
	}
	private String nome;
	private String cognome;
	private char genere;
	public HashMap<String, ArrayList<Integer>> votiStudenti = new HashMap<String, ArrayList<Integer>>();
	
	//costruttori
	
	public Studenti(String nome, String cognome, char genere) {
	
		this.nome = nome;
		this.cognome = cognome;
		this.genere = genere;
		this.votiStudenti = votiStudenti;
	    ArrayList<Integer>votiMatematica = new ArrayList<>();
	    ArrayList<Integer>votiStoria = new ArrayList<>();
	    ArrayList<Integer>votiInglese = new ArrayList<>();
	    ArrayList<Integer>votiAntropologia = new ArrayList<>();
	    
	    
	    ArrayList<Integer> voti_random = new ArrayList <>();
	    Random random = new Random();
	        for (int i = 0; i < 5; i++) {
	        	int prossimo_random = random.nextInt (2, 11);
	        	voti_random.add(prossimo_random);
	 
	    votiStudenti.put("Matematica", votiMatematica);
	    votiStudenti.put("Storia", votiStoria);
	    votiStudenti.put("Inglese",votiInglese);
	    votiStudenti.put("Antropologia", votiAntropologia);
	       
	   
	    
	        }
	        
	}


	//getters
	public static int getIdTot() {return idTot;}
    public String getNome() {return nome;}
    public String getCognome() {return cognome;}
    public char getGenere() {return genere;}
    public HashMap<String, ArrayList<Integer>> getVotiStudenti() {return votiStudenti;}

  //setters  
    public void setNome(String nome) {this.nome = nome;}
	public void setCognome(String cognome) {this.cognome = cognome;}
    public void setGenere(char genere) {this.genere = genere;}
    public void setVotiStudenti(HashMap<String, ArrayList<Integer>> votiStudenti) {this.votiStudenti = votiStudenti;}
	
   //metodi

public double mediaVotoMateria ()  {
	double somma = 0;
	for (Integer voto : this.votiStudenti()) {
		somma += voto;
		}
      return somma / this.votiStudenti.size();

}

private Integer[] votiStudenti() {
	return null;
}

//non ci capisco niente spero che nella settimana di ripasso riesca a colmare tutte le lacune.
      




	
	
	


}




