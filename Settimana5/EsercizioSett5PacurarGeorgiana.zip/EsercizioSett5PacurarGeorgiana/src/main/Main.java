package main;

import java.util.ArrayList;
import java.util.Scanner;
import poliziaMunicipale.AutoDAO;
import poliziaMunicipale.Infrazione;
import poliziaMunicipale.InfrazioneDAO;
import poliziaMunicipale.Auto;


public class Main {

	public static void main(String[] args) {
		
		   AutoDAO autoD = new AutoDAO ();
		   InfrazioneDAO infrazioneD = new InfrazioneDAO();
		
		  Scanner input = new Scanner(System.in);
			int m = 0;
			System.out.println("Premi 1 Per inserire un Auto  \nPremi 2 Per Inserire Infrazione \nPremi 3 Per sbirciare il DB \nPremi 4 Per cercare un auto \nPremi 5 per le indormazioni delle Infrazioni \nPremi 6 Per eliminare un Infrazione \nPremi 7 Per interrompere programma" ) ;
			 m = input.nextInt();
			
			switch (m) {
				case 1: {
					System.out.println("Digita Targa Auto");
					String targa = input.next();
					System.out.println("Digita Marca Auto");
					String marca = input.next();
					System.out.println("Digita Modello Auto");
					String modello = input.next();
					Auto auto = new Auto(targa, marca, modello);
					autoD.inserisciAuto(auto);
					System.out.println("Operazione riuscita con successo");
					
					
				}
				break;
				
				case 2: {
					System.out.println("Digita id");
					int id = input.nextInt();
					System.out.println("Digita data infrazione");
					String data = input.next();
					System.out.println("Digita tipo di infrazione");
					String prova = input.nextLine();
					String tipo = input.nextLine();
				    System.out.println("Digita importo infrazione");
					int importo = input.nextInt();
					System.out.println("Digita la targa dell'auto");
					String targa_auto = input.next();
					Infrazione infrazione = new Infrazione(id, data, tipo, importo, targa_auto);
					infrazioneD.inserisciInfrazione(infrazione);
					System.out.println("Operazione riuscita!");
				
				}
				break;
				
				case 3: {
				    ArrayList<Auto> automobili = autoD.getAllAuto();
				    System.out.println("Ecco tutte le informazioni!");
				    for (Auto auto : automobili) {
						System.out.println(auto.toString());
					
					}
				    
				}
				
				break;
				
				case 4: {
					System.out.println("Digita Targa");
					String targa = input.next();
			        autoD.cercaAuto(targa);
					System.out.println("Ecco la macchina da te cercata!");
				
				}
				break;
				
				case 5: {
		            infrazioneD.stampaDatiInfrazioniAuto();
					System.out.println("Ecco a te le informazioni");
				
				}
				break;
				
				case 6: {
					System.out.println("Elimina infrazione con l'id da lei digitato:");
					int id = input.nextInt();
					infrazioneD.eliminaInfrazione(id);
					System.out.println("Eliminazione riuscita. Ci vediamo alla prossima mazzetta");
			      
				}
				break;
				
				case 7: {
					System.out.println("Arrivederci e grazie");
				    input.close();
				    
					break;
				      
				}
			} 
			
	}


		

		
		
	}
		
		
		
		
		
	
		
			
		
	
		
		
		
		
		
		
	
	
	
	

