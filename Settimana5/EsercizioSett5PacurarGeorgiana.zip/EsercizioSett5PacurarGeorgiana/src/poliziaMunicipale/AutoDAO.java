package poliziaMunicipale;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import main.ConnectionFactory;

public class AutoDAO {

	public boolean inserisciAuto ( Auto auto)  {
		
		Connection connessione = ConnectionFactory.getConnection();
		String query = "INSERT INTO auto (targa, marca, modello) VALUES (?, ?, ?)";
		int numUpdate = 0;
		PreparedStatement ps = null;
		try  {
			ps = connessione.prepareStatement(query);
			ps.setString(1,auto.getTarga());
			ps.setString(2,auto.getMarca());
			ps.setString(3,auto.getModello());
			numUpdate = ps.executeUpdate();
		}catch (SQLException e)  {
			e.printStackTrace();
			
		}finally {
			try { ps.close(); } catch (SQLException e )  { e.printStackTrace();  }
			try { connessione.close();  } catch (SQLException e)  { e.printStackTrace();  }
		}
		if (numUpdate > 0)  {
			return true;
		}
		else { 
			return false;
		}
	}	
		public  ArrayList<Auto> getAllAuto()  {
			Connection connessione = ConnectionFactory.getConnection();
			Statement statement = null;
			try  {
				statement = connessione.createStatement();
				String query = "SELECT * FROM auto";
				ResultSet result = statement.executeQuery(query);
				ArrayList<Auto> automobili = new ArrayList<>();
				while (result.next())  {
					String targa_auto = result.getString(1);
					String marca_auto = result.getString(2);
					String modello_auto = result.getString(3);
					Auto auto = new Auto (targa_auto, marca_auto, modello_auto);
					automobili.add(auto);
					//System.out.println("Targa: " + auto.getTarga() + "\n" + "Marca: " + auto.getMarca() + "\n" + "Modello: " + auto.getModello());
				}
			    return automobili; 
				
			
			}	catch (SQLException e)  {
				System.out.println("Rilevato errore");
				e.printStackTrace();  }
		        
			    finally  {
			    	try  { statement.close(); }  catch (SQLException e)  {e.printStackTrace(); }
			    	try  { connessione.close();} catch (SQLException e)  {e.printStackTrace(); }
			}   System.out.println("Non esiste automobile!");
			
			return null;
			  
			    
	}
        public Auto cercaAuto (String targa)  {
        	
        	Connection connessione = ConnectionFactory.getConnection();
    		Statement statement = null;
    		try  {
    			statement = connessione.createStatement();
    			String query = "SELECT * FROM auto WHERE targa = '" + targa + "'";
    			ResultSet result = statement.executeQuery(query);
    			if (result.next())  {
    			    String marca_auto = result.getString("marca");
    				String modello_auto = result.getString("modello");
    				Auto auto = new Auto(targa, marca_auto, modello_auto);
    				System.out.println(auto.getTarga() + " " + auto.getMarca() + " " + auto.getModello());
    				return auto;
    			}
    			
    		}catch (SQLException e) {
    			e.printStackTrace();
    		} finally {
    			try { statement.close(); } catch (SQLException e) { e.printStackTrace(); }
    	        try { connessione.close(); } catch (SQLException e) { e.printStackTrace(); }
    		}
    		System.out.println("Sorry! Non esiste un auto con la targa indicata.");
    		return null;
        }
}
