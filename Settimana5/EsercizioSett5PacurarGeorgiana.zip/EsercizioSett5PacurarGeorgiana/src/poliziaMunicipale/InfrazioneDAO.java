package poliziaMunicipale;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import main.ConnectionFactory;

public class InfrazioneDAO {

public boolean inserisciInfrazione ( Infrazione infrazione)  {
		
		Connection connessione = ConnectionFactory.getConnection();
		String query = "INSERT INTO infrazione (id, data, tipo, importo, targa_auto) VALUES (?, ?, ?, ?, ?)";
		int numUpdate = 0;
		PreparedStatement ps = null;
		try  {
			ps = connessione.prepareStatement(query);
			ps.setInt(1,infrazione.getId());
			ps.setString(2,infrazione.getData());
			ps.setString(3,infrazione.getTipo());
			ps.setInt(4,infrazione.getImporto());
			ps.setString(5,infrazione.getTarga_auto());
			numUpdate = ps.executeUpdate();
		}catch (SQLException e)  {
			e.printStackTrace();
			
		}finally {
			try { ps.close(); } catch (SQLException e )  { e.printStackTrace();  }
			try { connessione.close();  } catch (SQLException e)  { e.printStackTrace();  }
		}
		if (numUpdate > 0)  {
			return true;
		}
		else { 
			return false;
		}

}
		public void stampaDatiInfrazioniAuto() {
			Connection connessione = ConnectionFactory.getConnection();
			Statement statement = null;
			try {
				statement = connessione.createStatement();
				String query = "SELECT * FROM auto inner join infrazione on auto.targa = infrazione.targa_auto";
				System.out.println("Informazioni ");
				System.out.println();
				ResultSet risultato = statement.executeQuery(query);
				while (risultato.next()) {
					int id_infrazione = risultato.getInt("id");
					String data_infrazione = risultato.getString("data");
					String tipo_infrazione = risultato.getString("tipo");
					int importo_infrazione = risultato.getInt("importo");
					String targa_auto_infrazione = risultato.getString("targa_auto");
					Infrazione infrazione = new Infrazione(id_infrazione, data_infrazione, tipo_infrazione, importo_infrazione, targa_auto_infrazione);
					System.out.println("id" + infrazione.getId() + "\n" + "data" + infrazione.getData() + "\n" + "tipo" + infrazione.getTipo() + "\n" + "importo" + infrazione.getImporto() + "\n" + "targa_auto" + infrazione.getTarga_auto());
				}
			} catch (SQLException e) {
		     	System.out.println("Rilevato un errore");
				e.printStackTrace();
			} finally {
	            try { statement.close(); } catch (SQLException e) { e.printStackTrace(); }
				try { connessione.close(); } catch (SQLException e) { e.printStackTrace(); }
			}
		}
		public boolean eliminaInfrazione (int id)     {
			Connection connessione = ConnectionFactory.getConnection();
			int numUpdate = 0;
			Statement statement = null;
			try {
				statement = connessione.createStatement ();
			    String query = "DELETE FROM infrazione WHERE id = " + id; 
			    numUpdate = statement.executeUpdate(query);
			}catch (SQLException e)  {
				e.printStackTrace();
				
			}finally {
				try { statement.close(); } catch (SQLException e )  { e.printStackTrace();  }
				try { connessione.close();  } catch (SQLException e)  { e.printStackTrace();  }
			}
			if (numUpdate > 0)  {
				return true;
			}
			else { 
				return false;
		}
		
		
		
		
		
		
	
	
	}
}