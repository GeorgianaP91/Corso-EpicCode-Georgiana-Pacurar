package poliziaMunicipale;

public class Infrazione {

	private int id;
	private String data;
	private String tipo;
	private int importo;
	private String targa_auto;
	
	
	
	
	
	public Infrazione() {}


	public Infrazione(int id, String data, String tipo, int importo, String targa_auto) {
	    
		this.id = id;
		this.data = data;
		this.tipo = tipo;
		this.importo = importo;
		this.targa_auto = targa_auto;
	}

    public int getId() {return id;}
    public void setId(int id) {this.id = id;}
    public String getData() {return data;}
    public void setData(String data) {this.data = data;}
    public String getTipo() {return tipo;}
    public void setTipo(String tipo) {this.tipo = tipo;}
    public int getImporto() {return importo;}
    public void setImporto(int importo) {this.importo = importo;}
    public String getTarga_auto() {return targa_auto;}
    public void setTarga_auto(String targa_auto) {this.targa_auto = targa_auto;}


	@Override
	public String toString() {
		return "Infrazione [id=" + id + ", data=" + data + ", tipo=" + tipo + ", importo=" + importo + ", targa_auto="
				+ targa_auto + "]";
	}
    
    
    
    
    
    
}
