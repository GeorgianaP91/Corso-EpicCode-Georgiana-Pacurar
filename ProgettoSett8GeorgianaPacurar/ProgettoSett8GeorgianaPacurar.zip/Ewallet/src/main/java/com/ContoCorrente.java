package com;

import java.util.ArrayList;
import java.util.List;

public class ContoCorrente {

	private String data;
	private String iban;
	private float saldo;
	private String intestatario;
	private List<String> listaMovimenti = new ArrayList<>();
	
	
	
	public List<String> getListaMovimenti() {return listaMovimenti;}
	public String getData() {return data;}
	public String getIban() {return iban;}
	public float getSaldo() {return saldo;}
	public String getIntestatario() {return intestatario;}
	
	public void setListaMovimenti(List<String> listaMovimenti) {this.listaMovimenti = listaMovimenti;}
    public void setData(String data) {this.data = data;}
    public void setIban(String iban) {this.iban = iban;}
    public void setSaldo(float saldo) {this.saldo = saldo;}
	public void setIntestatario(String intestatario) {this.intestatario = intestatario;}
	
	
}

