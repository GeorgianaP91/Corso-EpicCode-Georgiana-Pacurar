package com;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;




@Path("/contocorrente")
public class ContoCorrenteREST {

	private static List<ContoCorrente> listaConti = new ArrayList<>();

	@POST
	@Path("/crea")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response creaConto(ContoCorrente cc) {
		String result = "Hai creato un nuovo conto in data: " + cc.getData();
		listaConti.add(cc);
		cc.getListaMovimenti().add(result);
		return Response.status(201).entity(result).build();
	}

	@GET
	@Path("/cerca/{IbanDaCercare}")
	@Produces(MediaType.APPLICATION_JSON)
	public ContoCorrente cercaPerIban (@PathParam("IbanDaCercare")String IbanDaCercare) {
		ContoCorrente contocorrenteN = null;
		for (ContoCorrente contocorrente : listaConti) {
			if (contocorrente.getIban().equals(IbanDaCercare)) {
				contocorrenteN = contocorrente;
			}
		}
		return contocorrenteN;
	}
	@PUT
	@Path("/aggiorna/{IbanDaCercare}")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response aggiornaConto (@PathParam("IbanDaCercare")String IbanDaCercare, ContoCorrente contoN) {
		String result ="";
		ContoCorrente contocorrente = cercaPerIban(IbanDaCercare);
		if (listaConti.contains(contocorrente)) {
			int index = listaConti.lastIndexOf(contocorrente);
			contoN.setListaMovimenti(contocorrente.getListaMovimenti());
			listaConti.set(index, contoN);
			result = "Aggiornamento avvenuto con successo";
		}
		return Response.status(200).entity(result).build();
	}

	@PUT
	@Path("/versa/{IbanDaCercare}/{importo}")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response versa(@PathParam("IbanDaCercare") String IbanDaCercare, @PathParam("importo") float importo) {
		String result = "";
		ContoCorrente cc = cercaPerIban(IbanDaCercare);
		if (listaConti.contains(cc)) {
			if (importo > 0) {
				cc.setSaldo(cc.getSaldo() + importo);
				result = "Hai versato: " + importo + " €";
				cc.getListaMovimenti().add(result);
			} else {
				result = "Versamento non riuscito";
			}
		}
		return Response.status(200).entity(result).build();
	}
	@PUT
	@Path("/preleva/{IbanDaCercare}/{importo}")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response preleva(@PathParam("IbanDaCercare") String IbanDaCercare, @PathParam("importo") float importo) {
		String result = "";
		ContoCorrente cc = cercaPerIban(IbanDaCercare);
		if (listaConti.contains(cc)) {
			if (importo < cc.getSaldo()) {
				cc.setSaldo(cc.getSaldo() - importo);
				result = "Hai prelevato: " + importo + " €";
				cc.getListaMovimenti().add(result);
			} else {
				result = "Prelievo non risucito";
			}
		}
		return Response.status(200).entity(result).build();
	}
	
	
	
	@DELETE
	@Path("/cancella/{IbanDaCercare}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response cancella (@PathParam("searchIban")String IbanDaCercare) {
		String result ="Il contocorrente associato all'iban " + IbanDaCercare + " è stato cancellato" ;
		listaConti.remove(cercaPerIban(IbanDaCercare));
		return Response.status(200).entity(result).build();
	}
	
	@GET
	@Path("/listamovimenti/{IbanDaCercare}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<String> getListaMovimenti (@PathParam("searchIban")String IbanDaCercare) {
		return cercaPerIban(IbanDaCercare).getListaMovimenti();
	}


}