package it.epicode.segreteria.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import it.epicode.segreteria.service.SegreteriaService;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class SegreteriaController {

	@Autowired 
	SegreteriaService ss;
	
	@GetMapping("/")
	public ModelAndView Home () {
		ModelAndView mv = new ModelAndView("home-page");
		mv.addObject("titoloPagina", "Universitalia");
		return mv;
	}
	
	@GetMapping("/lista-corsi")
	public ModelAndView listaCorsi() {
		ModelAndView mv = new ModelAndView("lista-corsi");
		mv.addObject("elencoCorsi", ss.getCorsi());
				return mv;
	}
	
	@GetMapping("/lista-studenti")
	public ModelAndView listaStudenti() {
		ModelAndView mv = new ModelAndView("lista-studenti");
		mv.addObject("elencoStudenti", ss.getStudenti());
			return mv;
}
}