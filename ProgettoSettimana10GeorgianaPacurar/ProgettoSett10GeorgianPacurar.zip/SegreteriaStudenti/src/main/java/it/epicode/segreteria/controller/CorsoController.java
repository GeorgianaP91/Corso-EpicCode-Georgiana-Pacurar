package it.epicode.segreteria.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import it.epicode.segreteria.model.Corso;
import it.epicode.segreteria.model.Studente;
import it.epicode.segreteria.service.SegreteriaService;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class CorsoController {


	@Autowired
	SegreteriaService ss;

	 @GetMapping("/form-inserisci-corso")
	 public ModelAndView formInserisciCorso() {
			ModelAndView mv = new ModelAndView("form-inserisci-corso", "corso", new Corso());
			//mv.addObject("listaCorsi", ss.getCorsi());
			return mv;
	 }
	 
	 @PostMapping("/post-inserisci-corso")
	 public ModelAndView postInserisciCorso(@Valid @ModelAttribute Corso corso, BindingResult result) {
		 if(result.hasErrors()) {
			 return new ModelAndView("error", HttpStatus.BAD_REQUEST);
		 }
		 ss.inserisciCorso(corso);
		 ModelAndView mv = new ModelAndView("redirect:/lista-corsi");
		 return mv;
	 }
	 

	 @GetMapping("/form-modifica-corso/{id}")
	 public ModelAndView formModificaCorso(@PathVariable("id") String id) {
			ModelAndView mv = new ModelAndView("form-modifica-corso", " corso", ss.trovaCorso(id));
			mv.addObject("elencoCorsi", ss.getCorsi());
			mv.addObject("elencoStudenti", ss.getStudenti());
			return mv;
	 }
	 @PostMapping("/post-modifica-corso")
	 public ModelAndView postmodificaCorso(@ModelAttribute Corso corso, BindingResult result) {
		 if(result.hasErrors()) {
			 return new ModelAndView("error", HttpStatus.BAD_REQUEST);
		 }
		 ss.modificaCorso(corso);
		 ModelAndView mv = new ModelAndView("redirect:/lista-corsi");
		 return mv;
	 
	 }
	 @GetMapping("/form-elimina-corso/{id}")
	 public ModelAndView formEliminaCorso(@PathVariable("id") String id) {
		 ModelAndView mv = new ModelAndView("form-elimina-corso", "corso", ss.trovaCorso(id));
		 mv.addObject("elencoCorso", ss.getCorsi());
		 return mv;
		
	 }

	 @DeleteMapping("/delete-elimina-corso")
	 public ModelAndView deleteEliminaCorso(@ModelAttribute Corso corso, String id, BindingResult result) {
		 if(result.hasErrors()) {
			 return new ModelAndView("error", HttpStatus.BAD_REQUEST);
		 }
		 ss.eliminaCorso(corso, id);
		return new ModelAndView("redirect:/listacorsi", HttpStatus.OK);
	 }

}

	

