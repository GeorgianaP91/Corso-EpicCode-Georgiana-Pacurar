package it.epicode.segreteria.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import it.epicode.segreteria.model.Corso;
import it.epicode.segreteria.model.Studente;
import it.epicode.segreteria.repository.CorsoRepository;
import it.epicode.segreteria.repository.StudenteRepository;

@Service
public class SegreteriaService {

	@Autowired
	CorsoRepository cr;
	@Autowired
	StudenteRepository sr;
	
	public List<Studente> getStudenti() {
		return (List<Studente>) sr.findAll();
	}
	
	public List<Corso> getCorsi() {
		return (List<Corso>) cr.findAll();
	}
	
	 
    public void inserisciStudente(Studente studente) {
    	if(!sr.existsById(studente.getMatricola())) {
    		sr.save(studente);
    	}
    }
    public void inserisciCorso(Corso corso) {
    	if(!cr.existsById(corso.getId())) {
    		cr.save(corso);
    	}
    }
    public void modificaStudente(Studente studente) {
    	if(sr.existsById(studente.getMatricola())) {
    		sr.findById(studente.getMatricola()).get();
    		sr.save(studente);
    	}
    }
    public Studente trovaStudente (String matricola) {
    	if(sr.existsById(matricola)) {
    		Studente studente= sr.findById(matricola).get();
    		return studente;
    	}
    	return new Studente();
    }
	
    public void eliminaStudente (Studente studente, String matricola) {
    	if(sr.existsById(matricola)) {
    	sr.delete(studente);
    		
    	}
    }
    public void modificaCorso(Corso corso) {
    	if(cr.existsById(corso.getId())) {
    		cr.save(corso);
    	}
    }
    public Studente trovaCorso (String id) {
    	if(cr.existsById(id)) {
    		Studente studente= sr.findById(id).get();
    		return studente;
    	}
    	return new Studente();
    }
	
    public void eliminaCorso (Corso corso, String id) {
    	if(cr.existsById(id)) {
    	cr.deleteById(id);
    		
    	}
    }
}
