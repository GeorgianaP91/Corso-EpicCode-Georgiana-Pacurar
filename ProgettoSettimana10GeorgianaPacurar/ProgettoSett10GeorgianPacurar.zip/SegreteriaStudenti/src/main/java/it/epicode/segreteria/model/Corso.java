package it.epicode.segreteria.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
public class Corso {

	@Id
	private String id;
	private String nome;
	private String indirizzo;
	private int numeroEsami;
	@OneToMany(mappedBy = "corsoLaurea", cascade = CascadeType.ALL)
	private List<Studente> studenti;
}
