package it.epicode.segreteria.runner;

import org.springframework.stereotype.Component;

@Component
public class CorsoRunner {

}
