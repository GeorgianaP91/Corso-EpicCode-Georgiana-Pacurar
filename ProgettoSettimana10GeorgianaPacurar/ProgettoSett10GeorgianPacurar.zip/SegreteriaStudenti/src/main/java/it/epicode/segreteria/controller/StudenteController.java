package it.epicode.segreteria.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.servlet.ModelAndView;


import it.epicode.segreteria.model.Studente;
import it.epicode.segreteria.service.SegreteriaService;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class StudenteController {

	@Autowired
	SegreteriaService ss;

	 @GetMapping("/form-inserisci-studente")
	 public ModelAndView formInserisciStudente() {
			ModelAndView mv = new ModelAndView("form-inserisci-studente", "studente", new Studente());
			mv.addObject("elencoCorsi", ss.getCorsi());
			return mv;
	 }
	 
	 @PostMapping("/post-inserisci-studente")
	 public ModelAndView postInserisciStudente(@Valid @ModelAttribute Studente studente, BindingResult result) {
		 if(result.hasErrors()) {
			 return new ModelAndView("error", HttpStatus.BAD_REQUEST);
		 }
		 ss.inserisciStudente(studente);
		 ModelAndView mv = new ModelAndView("redirect:/lista-studenti");
		 return mv;
	 }
 
	 @GetMapping("/form-modifica-studente/{matricola}")
	 public ModelAndView formModificaStudente(@PathVariable("matricola") String matricola) {
			ModelAndView mv = new ModelAndView("form-modifica-studente", "studente", ss.trovaStudente(matricola));
			mv.addObject("elencoCorsi", ss.getCorsi());
			mv.addObject("elencoStudenti", ss.getStudenti());
			return mv;
	 }
	 @PostMapping("/post-modifica-studente")
	 public ModelAndView postmodificaStudente(@ModelAttribute Studente studente, BindingResult result) {
		 if(result.hasErrors()) {
			 return new ModelAndView("error", HttpStatus.BAD_REQUEST);
		 }
		 ss.modificaStudente(studente);
		 ModelAndView mv = new ModelAndView("redirect:/lista-studenti");
		 return mv;
	 
	 }
	 @GetMapping("/form-elimina-studente/{matricola}")
	 public ModelAndView formEliminaStudente(@PathVariable("matricola") String matricola) {
		 ModelAndView mv = new ModelAndView("form-elimina-studente", "studente", ss.trovaStudente(matricola));
		 mv.addObject("elencoStudenti", ss.getStudenti());
		 return mv;
		
	 }

	 @DeleteMapping("/delete-elimina-studente")
	 public ModelAndView deleteEliminaStudente(@ModelAttribute Studente studente, String matricola, BindingResult result) {
		 if(result.hasErrors()) {
			 return new ModelAndView("error", HttpStatus.BAD_REQUEST);
		 }
		 ss.eliminaStudente(studente, matricola);
		return new ModelAndView("redirect:/listastudenti", HttpStatus.OK);
	 }
}