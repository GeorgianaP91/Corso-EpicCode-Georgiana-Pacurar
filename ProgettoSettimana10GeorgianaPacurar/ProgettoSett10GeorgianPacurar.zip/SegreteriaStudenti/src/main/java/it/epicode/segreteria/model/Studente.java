package it.epicode.segreteria.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import it.epicode.segreteria.repository.CorsoRepository;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor

public class Studente {

	@Id
	private String matricola;
	private String nome;
	private String cognome;
	private String dataNascita;
	private String email;
	private String citta;
	private String indirizzo;
	@JoinColumn(name="id_corso")
	@ManyToOne(cascade = CascadeType.ALL)
	private Corso corsoLaurea;
}

