package it.epicode.presentation;

import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;



import it.epicode.business.RubricaWebEJB;
import it.epicode.rubrica.Contatto;
import it.epicode.rubrica.NumTelefoni;



public class CercaContattoPerNumero extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@EJB 
	RubricaWebEJB rejb; 
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CercaContattoPerNumero() {}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String numTelefono= request.getParameter("numTelefono");
		Contatto c = (Contatto) rejb.cercaContattoPerNumero(numTelefono);
		
		if(c!=null) 
			response.getWriter()
			.append(c.getNome())
			.append(c.getCognome())
			.append(c.getEmail())
			.append((CharSequence) c.getNumTelefoni());
		else {
			response.getWriter()
			.append("Contatto non trovato");
		}
		
	}

}
