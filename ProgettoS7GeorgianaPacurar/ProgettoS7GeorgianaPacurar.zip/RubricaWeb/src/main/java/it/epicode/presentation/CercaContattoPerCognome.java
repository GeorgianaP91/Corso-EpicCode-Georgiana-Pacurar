package it.epicode.presentation;

import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;



import it.epicode.business.RubricaWebEJB;
import it.epicode.rubrica.Contatto;


 

public class CercaContattoPerCognome extends HttpServlet {
	private static final long serialVersionUID = 1L;
	  @EJB 
	   RubricaWebEJB rejb;
   
	  public CercaContattoPerCognome() {

     
    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String cognome = request.getParameter("cognome");
		
		List<Contatto> lc = rejb.cercaContattoPerCognome(cognome);
		
		response.getWriter().append("Lista Contatti").append("<br>");
		for(Contatto c: lc) {
			response.getWriter()
			.append(c.getNome())
			.append(" ")
			.append(c.getCognome())
			.append("<br>")
			;
	}
	}
}
