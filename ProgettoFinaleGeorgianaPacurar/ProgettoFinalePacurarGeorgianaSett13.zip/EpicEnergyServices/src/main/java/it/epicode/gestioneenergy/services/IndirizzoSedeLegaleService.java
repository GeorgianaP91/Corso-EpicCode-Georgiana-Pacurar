package it.epicode.gestioneenergy.services;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.epicode.gestioneenergy.dto.FatturaDto;
import it.epicode.gestioneenergy.dto.IndirizzoSedeLegaleDto;
import it.epicode.gestioneenergy.model.Cliente;
import it.epicode.gestioneenergy.model.Comune;
import it.epicode.gestioneenergy.model.Fattura;
import it.epicode.gestioneenergy.model.IndirizzoSedeLegale;
import it.epicode.gestioneenergy.repository.ClienteRepository;
import it.epicode.gestioneenergy.repository.ComuneRepository;
import it.epicode.gestioneenergy.repository.IndirizzoSedeLegaleRepository;

@Service
public class IndirizzoSedeLegaleService {

	@Autowired
	ClienteRepository cr;
	@Autowired
	ComuneRepository cor;
	@Autowired
	IndirizzoSedeLegaleRepository islr;
	
	public void inserisciIndirizzoSedeLegale(IndirizzoSedeLegaleDto dto) {
		IndirizzoSedeLegale il = new IndirizzoSedeLegale();
		Cliente c = cr.findById(dto.getPartitaIva()).get();
		Comune co = cor.findById(dto.getId_comuneSL()).get();
		il.getCliente();
		il.getId();
	    BeanUtils.copyProperties(dto, il);
		islr.save(il);
	}	
	public boolean eliminaIndirizzoSedeLegale( int id_indsl) {
		if(!islr.existsById(id_indsl)) {
			return false;
		}
		islr.deleteById(id_indsl);
		return true;

}
	public boolean modificaIndirizzoSedeLegale (IndirizzoSedeLegaleDto dto, int id_indsl) {
		if(!islr.existsById(dto.getId()) && !cr.existsById(dto.getPartitaIva())&& !cor.existsById(dto.getId_comuneSL())) {
			return false;
	}
		IndirizzoSedeLegale il = islr.findById(id_indsl).get();
		Cliente c = cr.findById(dto.getPartitaIva()).get();
		Comune co = cor.findById(dto.getId_comuneSL()).get();
		il.setCliente(c);
		il.setComuneSL(co);
	    BeanUtils.copyProperties(dto, il);
	    il.setId(id_indsl);
		islr.save(il);
		return true;
	}	

	public List<IndirizzoSedeLegale> mostraTuttiIndirizzi() {
		return (List<IndirizzoSedeLegale>) islr.findAll();
	}
	
	public IndirizzoSedeLegale cercaPerId (int id_indsl) {
		if(!islr.existsById(id_indsl)) {
			return null;
		}
		return islr.findById(id_indsl).get();
	}
}

	

