package it.epicode.gestioneenergy.dto;

import java.math.BigDecimal;

import it.epicode.gestioneenergy.model.Cliente;
import it.epicode.gestioneenergy.model.StatoFattura;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class FatturaDto {

	private int numero;
	private int anno;
	private String data;
	private double importo;
	private String id_cliente;
	private StatoFattura stato;
}
