package it.epicode.gestioneenergy.runner;

import java.io.File;
import java.util.List;
import java.util.Optional;

import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;

import org.springframework.beans.BeanUtils;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import it.epicode.gestioneenergy.csv.ComuneCSV;
import it.epicode.gestioneenergy.csv.ProvinciaCSV;
import it.epicode.gestioneenergy.model.Comune;
import it.epicode.gestioneenergy.model.Provincia;
import it.epicode.gestioneenergy.repository.ComuneRepository;
import it.epicode.gestioneenergy.repository.ProvinciaRepository;
import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
@Component
public class CsvRunner implements ApplicationRunner {
		
		ComuneRepository comuneRepo;
		ProvinciaRepository provinciaRepo;

		@Override
		public void run(ApplicationArguments args) throws Exception {
			
		       String fileProvinciaCSV = "csv/province-italiane.csv";
		        CsvSchema provinciaCSVSchema = CsvSchema.emptySchema().withColumnSeparator(';').withHeader();
		        CsvMapper mapper = new CsvMapper();
		        File fileProvincia = new ClassPathResource(fileProvinciaCSV).getFile();
		        MappingIterator<List<String>> valueReader = mapper
		                .reader(ProvinciaCSV.class)
		                .with(provinciaCSVSchema)
		                .readValues(fileProvincia);
		        for(Object o : valueReader.readAll()) {
		            Provincia p = new Provincia();
		            ProvinciaCSV csv = (ProvinciaCSV) o;
		            BeanUtils.copyProperties(o, p);
		            if(p.getSigla()!=null) {
		                provinciaRepo.save(p);
		            }
		        }
			
		        String fileComuneCSV = "csv/comuni.csv";
		        CsvSchema comuneCSVSchema = CsvSchema.emptySchema().withColumnSeparator(';').withHeader();
		        CsvMapper mapper1 = new CsvMapper();
		        File fileComune = new ClassPathResource(fileComuneCSV).getFile();
		        MappingIterator<List<String>> valueReader1 = mapper1
		                .reader(ComuneCSV.class)
		                .with(comuneCSVSchema)
		                .readValues(fileComune);
		        for(Object o : valueReader1.readAll()) {
		            Comune c = new Comune();
		            ComuneCSV csv = (ComuneCSV) o;
		            Optional<Provincia> p = provinciaRepo.findById(csv.getProvincia());
		            
		            if(p.isPresent()) {
		                BeanUtils.copyProperties(o, c);
		                c.setProvincia(p.get());
		              
		                if(c.getCap() != null) {
		            
		                    comuneRepo.save(c);
		                }
		            }
		        }
		}
	
	}


