package it.epicode.gestioneenergy.repository;

import org.springframework.data.repository.PagingAndSortingRepository;

import it.epicode.gestioneenergy.model.Provincia;

public interface ProvinciaRepository extends PagingAndSortingRepository<Provincia, String> {

}
