package it.epicode.gestioneenergy.runner;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import it.epicode.gestioneenergy.impl.ERole;
import it.epicode.gestioneenergy.impl.Role;
import it.epicode.gestioneenergy.impl.RoleRepository;
import it.epicode.gestioneenergy.impl.User;
import it.epicode.gestioneenergy.impl.UserRepository;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class UserRunner implements CommandLineRunner{
	@Autowired
	UserRepository ur;
	@Autowired
	RoleRepository rr;
	@Autowired
	PasswordEncoder encoder;
	@Override
	public void run(String... args) throws Exception {
		Set<Role> roles = new HashSet<Role>();
		Set hash = new HashSet<Role>();
		Role admin = Role.builder().roleName(ERole.ROLE_ADMIN).build();
		hash.add(admin);
		Set hash1 = new HashSet<Role>();
		Role user = Role.builder().roleName(ERole.ROLE_USER).build();
		hash1.add(user);		
		User u = User.builder().username("Georgiana").password(BCrypt.hashpw("patata", BCrypt.gensalt())).roles(hash).build();
		User u1 = User.builder().username("Ospite").password(BCrypt.hashpw("ospite", BCrypt.gensalt())).roles(hash1).build();
		ur.save(u);
		ur.save(u1);
	}
}
