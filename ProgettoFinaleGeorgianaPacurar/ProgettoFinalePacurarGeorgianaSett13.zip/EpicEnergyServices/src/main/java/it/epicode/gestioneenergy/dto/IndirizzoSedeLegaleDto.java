package it.epicode.gestioneenergy.dto;

import java.math.BigDecimal;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class IndirizzoSedeLegaleDto {

	private int id;
	private String via;
    private int civico;
    private String localita;
    private String cap;
    private int id_comuneSL;
    private String partitaIva;
}
