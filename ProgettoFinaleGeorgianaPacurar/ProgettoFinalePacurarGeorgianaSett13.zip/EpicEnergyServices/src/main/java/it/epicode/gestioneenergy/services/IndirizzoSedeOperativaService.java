package it.epicode.gestioneenergy.services;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.epicode.gestioneenergy.dto.IndirizzoSedeLegaleDto;
import it.epicode.gestioneenergy.dto.IndirizzoSedeOperativaDto;
import it.epicode.gestioneenergy.model.Cliente;
import it.epicode.gestioneenergy.model.Comune;
import it.epicode.gestioneenergy.model.IndirizzoSedeLegale;
import it.epicode.gestioneenergy.model.IndirizzoSedeOperativa;
import it.epicode.gestioneenergy.repository.ClienteRepository;
import it.epicode.gestioneenergy.repository.ComuneRepository;
import it.epicode.gestioneenergy.repository.IndirizzoSedeLegaleRepository;
import it.epicode.gestioneenergy.repository.IndirizzoSedeOperativaRepository;

@Service
public class IndirizzoSedeOperativaService {

	@Autowired
	ClienteRepository cr;
	@Autowired
	ComuneRepository cor;
	@Autowired
	IndirizzoSedeOperativaRepository isor;
	
	public void inserisciIndirizzoSedeOperativa(IndirizzoSedeOperativaDto dto) {
		IndirizzoSedeOperativa io = new IndirizzoSedeOperativa();
		Cliente c = cr.findById(dto.getPartitaIva()).get();
		Comune co = cor.findById(dto.getId_comuneSO()).get();
		io.getCliente();
		io.getId();
	    BeanUtils.copyProperties(dto, io);
		isor.save(io);
	}	
	public boolean eliminaIndirizzoSedeOperativa( int id_indso) {
		if(!isor.existsById(id_indso)) {
			return false;
		}
		isor.deleteById(id_indso);
		return true;

}
	public boolean modificaIndirizzoSedeOperativa (IndirizzoSedeOperativaDto dto, int id_indso) {
		if(!isor.existsById(dto.getId()) && !cr.existsById(dto.getPartitaIva()) && !cor.existsById(dto.getId_comuneSO())) {
			return false;
	}
		IndirizzoSedeOperativa io = isor.findById(id_indso).get();
		Cliente c = cr.findById(dto.getPartitaIva()).get();
		Comune co = cor.findById(dto.getId_comuneSO()).get();
		io.setCliente(c);
		io.setComuneSO(co);
	    BeanUtils.copyProperties(dto, io);
	    io.setId(id_indso);
		isor.save(io);
		return true;
	}	

	public List<IndirizzoSedeOperativa> mostraTuttiIndirizzi() {
		return (List<IndirizzoSedeOperativa>) isor.findAll();
	}
	
	public IndirizzoSedeOperativa cercaPerId (int id_indso) {
		if(!isor.existsById(id_indso)) {
			return null;
		}
		return isor.findById(id_indso).get();
	}
}

