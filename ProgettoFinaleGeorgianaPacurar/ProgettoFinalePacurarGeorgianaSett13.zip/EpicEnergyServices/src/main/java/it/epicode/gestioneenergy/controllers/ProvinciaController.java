package it.epicode.gestioneenergy.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import it.epicode.gestioneenergy.dto.ComuneDto;
import it.epicode.gestioneenergy.dto.ProvinciaDto;
import it.epicode.gestioneenergy.errors.ElementAlreadyPresentException;
import it.epicode.gestioneenergy.errors.ElementNotFoundException;
import it.epicode.gestioneenergy.model.Comune;
import it.epicode.gestioneenergy.model.Provincia;
import it.epicode.gestioneenergy.services.ComuneService;
import it.epicode.gestioneenergy.services.ProvinciaService;

/**
 * 
 * @author Georgiana Pacurar
 * Servizi REST relativi alla classe provincia
 * 
 */
@RestController
@RequestMapping("/provincia")
@Tag(name = "Provincia rest servicies", description = "implementazioni delle api rest delle Province")
public class ProvinciaController {
	
	@Autowired
	ProvinciaService ps;

	/**
	 * Inserisce una provincia nel db
	 * @param dto
	 * @return
	 * @throws ElementAlreadyPresentException
	 */
	@Operation( summary = "Inserisce una Provincia nel DB", description = "Inserimento di una Provincia")
	@ApiResponse(responseCode = "200", description = "Provincia inserita correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nell'inserimento")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@PostMapping("/")
	public ResponseEntity inserisciProvincia(@RequestBody @Valid ProvinciaDto dto) throws ElementAlreadyPresentException {
		ps.inserisciProvincia(dto);
		return ResponseEntity.ok("Provincia inserita");
}
	/**
	 * 
	 * Elimina una provincia da un db
	 * @param sigla
	 * @return
	 * @throws ElementNotFoundException
	 */
	@Operation( summary = "Elimina una Provincia nel DB", description = "Eliminazione di una Provincia per sigla")
	@ApiResponse(responseCode = "200", description = "Provincia eliminata correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nell'eliminazione")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@DeleteMapping("/eliminaprovincia/{sigla}")
	public ResponseEntity eliminaProvincia(@PathVariable("sigla") String id_provincia)throws ElementNotFoundException {
		boolean okFindIt = ps.eliminaProvincia(id_provincia);
		if(okFindIt) {
		return ResponseEntity.ok("Provincia Eliminata");
		} return new ResponseEntity("Provincia non trovata", HttpStatus.NOT_FOUND);
}
	/**
	 * Modifica gli attributi di una provincia
	 * @param sigla
	 * @param dto
	 * @return
	 * @throws ElementNotFoundException
	 */
	@Operation( summary = "Modifica una Provincia nel DB", description = "Modifica di una Provincia cercandola per sigla")
	@ApiResponse(responseCode = "200", description = "Provincia modificata correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nella modifica")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@PutMapping("/modificaprovincia/{sigla}")
	public ResponseEntity modificaProvincia (@PathVariable("sigla") String id_provincia, @Valid @RequestBody ProvinciaDto dto) throws ElementNotFoundException{
		boolean bb = ps.modificaProvincia(dto, id_provincia);
		if(bb) {
			return ResponseEntity.ok("Provincia Modificata con successo");
			
		}return new ResponseEntity("Provincia non esistente o non trovata!", HttpStatus.NOT_FOUND);
	}
	/**
	 * Ricerca una lista di province
	 * @return
	 */
	@Operation( summary = "Ricerca una lista di province nel DB", description = "Ricerca di una lista di province")
	@ApiResponse(responseCode = "200", description = "Province trovate correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nella ricerca")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/mostraprovince")
	public ResponseEntity mostraTutteProvince () {
		return ResponseEntity.ok(ps.mostraTutteProvince());
	}
	/**
	 * Ricerca una provincia tramite sigla
	 * @param sigla
	 * @return
	 */
	@Operation( summary = "Ricerca una Provincia nel DB per sigla", description = "Ricerca di una Provincia")
	@ApiResponse(responseCode = "200", description = "Provincia trovata correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nella ricerca")
	@GetMapping("/{sigla}")
	public ResponseEntity cercaProvinciaPerId(@PathVariable("sigla")String id_provincia) {
		Provincia p = ps.cercaPerId(id_provincia);
		if(p == null) {
			return new ResponseEntity("Provincia non trovata", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(p);
}
}