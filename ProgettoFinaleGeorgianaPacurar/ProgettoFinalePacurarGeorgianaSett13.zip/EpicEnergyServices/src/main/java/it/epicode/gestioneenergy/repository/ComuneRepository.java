package it.epicode.gestioneenergy.repository;

import org.springframework.data.repository.PagingAndSortingRepository;

import it.epicode.gestioneenergy.model.Comune;

public interface ComuneRepository extends PagingAndSortingRepository<Comune, Integer> {

}
