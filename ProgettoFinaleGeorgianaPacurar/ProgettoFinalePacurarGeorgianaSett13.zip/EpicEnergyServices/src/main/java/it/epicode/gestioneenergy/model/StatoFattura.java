package it.epicode.gestioneenergy.model;
/**
 * Classe che gestisce l'enum dello stato della fattura
 * @author
 */
public enum StatoFattura {

	PAGATO,
	NON_PAGATO,
	IN_CORSO;
}
