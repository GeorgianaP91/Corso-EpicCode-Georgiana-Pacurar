package it.epicode.gestioneenergy.controllers;


import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import it.epicode.gestioneenergy.errors.ElementAlreadyPresentException;
import it.epicode.gestioneenergy.errors.ElementNotFoundException;
import it.epicode.gestioneenergy.dto.ClienteDto;
import it.epicode.gestioneenergy.dto.GetDataInserimentoBetweenDto;
import it.epicode.gestioneenergy.dto.GetDataUltimoContattoBetweenDto;
import it.epicode.gestioneenergy.dto.GetFatturatoAnnualeBetweenDto;
import it.epicode.gestioneenergy.model.Cliente;
import it.epicode.gestioneenergy.services.ClienteService;

/**
 * 
 * @author Georgiana Pacurar
 * Servizi REST relativi alla classe cliente
 * 
 */
@RestController
@RequestMapping("/cliente")
@Tag(name = "Cliente rest servicies", description = "implementazioni delle api rest dei Clienti")
public class ClienteController {
	
	@Autowired
	ClienteService cs;

	/**
	 * Inserisce un cliente nel db
	 * @param dto
	 * @return
	 * @throws ElementAlreadyPresentException
	 */
	@Operation( summary = "Inserisce un Cliente nel DB", description = "Inserimento di un Cliente con: partita Iva, Ragione Sociale, Email, Data di Inserimento, Data dell'ultimo contatto, Fatturato annuale, Pec, Telefono, nome, cognome ")
	@ApiResponse(responseCode = "200", description = "Cliente inserito correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nell'inserimento")
	@PostMapping("/")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	
	public ResponseEntity inserisciCliente (@RequestBody @Valid ClienteDto dto) throws ElementAlreadyPresentException {
		cs.inserisciCliente(dto);
		return ResponseEntity.ok("Cliente inserito");
}
	/**
	 * 
	 * Elimina un cliente da un db
	 * @param partitaIva
	 * @return
	 * @throws ElementNotFoundException
	 */
	@Operation( summary = "Elimina un Cliente nel DB", description = "Eliminazione di un Cliente per partita iva")
	@ApiResponse(responseCode = "200", description = "Cliente eliminato correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nell'eliminazione")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@DeleteMapping("/{partitaIva}")
	public ResponseEntity eliminaCliente(@PathVariable("partitaIva") String id_cliente)throws ElementNotFoundException {
		boolean okFindIt = cs.eliminaCliente(id_cliente);
		if(okFindIt) {
		return ResponseEntity.ok("Cliente Eliminato");
		} return new ResponseEntity("Cliente non trovato", HttpStatus.NOT_FOUND);
}
	/**
	 * Modifica gli attributi di un cliente
	 * @param partita iva
	 * @param dto
	 * @return
	 * @throws ElementNotFoundException
	 */
	@Operation( summary = "Modifica un Cliente nel DB", description = "Modifica di un Cliente cercandolo per partita iva")
	@ApiResponse(responseCode = "200", description = "Cliente modificato correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nella modifica")
	@PreAuthorize("hasRole('ADMIN')")
	@PutMapping("/modificacliente/{partitaIva}")
	@SecurityRequirement(name = "bearerAuth")
	public ResponseEntity modificaCliente (@PathVariable("partitaIva") String id_cliente, @Valid @RequestBody ClienteDto dto) throws ElementNotFoundException{
		boolean bb = cs.modificaCliente(dto, id_cliente);
		if(bb) {
			return ResponseEntity.ok("Cliente Modificato con successo");
			
		}return new ResponseEntity("Cliente non esistente o non trovato!", HttpStatus.NOT_FOUND);
	}
	/**
	 * Ricerca una lista di clienti
	 * @return
	 */
	@Operation( summary = "Ricerca una lista di clienti nel DB", description = "Ricerca di una lista di clienti con: partita Iva, Ragione Sociale, Email, Data di Inserimento, Data dell'ultimo contatto, Fatturato annuale, Pec, Telefono, nome, cognome ")
	@ApiResponse(responseCode = "200", description = "Clienti trovati correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nella ricerca")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/cerca")
	public ResponseEntity mostraTuttiClienti () {
		return ResponseEntity.ok(cs.mostraTuttiClienti());
	}
	/**
	 * Ricerca un cliente tramite partita iva
	 * @param partita iva
	 * @return
	 */
	@Operation( summary = "Ricerca un Cliente nel DB per partita iva", description = "Ricerca di un Cliente con:partita Iva, Ragione Sociale, Email, Data di Inserimento, Data dell'ultimo contatto, Fatturato annuale, Pec, Telefono, nome, cognome ")
	@ApiResponse(responseCode = "200", description = "Cliente trovato correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nella ricerca")
	@GetMapping("/{partitaIva}")
	public ResponseEntity cercaClientePerId(@PathVariable("partitaIva")String id_cliente) {
		Cliente c = cs.cercaPerId(id_cliente);
		if(c == null) {
			return new ResponseEntity("Cliente non trovato", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(c);
	}
	/**
	 * Ordina i clienti per nome
	 * @param page
	 * @return
	 */
	@Operation( summary = "Ordina un Cliente nel DB per nome", description = "Ordina di un Cliente con:partita Iva, Ragione Sociale, Email, Data di Inserimento, Data dell'ultimo contatto, Fatturato annuale, Pec, Telefono, nome, cognome ")
	@ApiResponse(responseCode = "200", description = "Cliente trovato correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nella ricerca")
	@GetMapping("/ordina-per-nome")
	public ResponseEntity OrdinaClientiPerNome (Pageable page) {
		return ResponseEntity.ok(cs.getAllByOrderByNomeContatto());
	}
	/**
	 * Ordina i clienti per fatturato annuale
	 * @param page
	 * @return
	 */
	@Operation( summary = "Ordina un Cliente nel DB per fatturato annuale", description = "Ordina di un Cliente con:partita Iva, Ragione Sociale, Email, Data di Inserimento, Data dell'ultimo contatto, Fatturato annuale, Pec, Telefono, nome, cognome ")
	@ApiResponse(responseCode = "200", description = "Cliente trovato correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nella ricerca")
	@GetMapping("/ordina-per-fatturato")
	public ResponseEntity OrdinaClientiPerFatturatoAnnuale (Pageable page) {
		return ResponseEntity.ok(cs.getAllByOrderByFatturatoAnnuale());
	}
	/**
	 * Ordina i clienti per data inserimento
	 * @param page
	 * @return
	 */
	@Operation( summary = "Ordina un Cliente nel DB per data inserimento", description = "Ordina di un Cliente con:partita Iva, Ragione Sociale, Email, Data di Inserimento, Data dell'ultimo contatto, Fatturato annuale, Pec, Telefono, nome, cognome ")
	@ApiResponse(responseCode = "200", description = "Cliente trovato correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nella ricerca")
	@GetMapping("/ordina-per-data-inserimento")
	public ResponseEntity OrdinaClientiPerDataInserimento (Pageable page) {
		return ResponseEntity.ok(cs.getAllByOrderByDataInserimento());
}
	/**
	 * Ordina i clienti per la data dell'ultimo contatto
	 * @param page
	 * @return
	 */
	@Operation( summary = "Ordina un Cliente nel DB per data ultimo contatto", description = "Ordina di un Cliente con:partita Iva, Ragione Sociale, Email, Data di Inserimento, Data dell'ultimo contatto, Fatturato annuale, Pec, Telefono, nome, cognome ")
	@ApiResponse(responseCode = "200", description = "Cliente trovato correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nella ricerca")
	@GetMapping("/ordina-data-ultimo-contatto")
	public ResponseEntity OrdinaClientiPerDataUltimoContatto (Pageable page) {
		return ResponseEntity.ok(cs.getAllByOrderByDataUltimoContatto());
}
   /**
    * 
    * Filtra cliente per nome
    * @param nomeContatto
    * @param page
    * @return
    * @throws ElementNotFoundException
    */

	@Operation( summary = "Filtra Cliente nel DB per nome", description = "Filtra Cliente per nome")
	@ApiResponse(responseCode = "200", description = "Cliente trovato correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nella ricerca")
	@PostMapping("/nomecontaining/{nomeContatto}")
	public ResponseEntity getNomeContatto (@PathVariable("nomeContatto") String nomeContatto, Pageable page) throws ElementNotFoundException {
		List<Cliente> c = cs.getNomeContattoContaining(nomeContatto, page);
		if(c==null) {
			return new ResponseEntity("Cliente non trovato", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(c);
	}

	/**
	 * Filtra cliente per dataUltimoContatto
	 * @param dto
	 * @param page
	 * @return
	 * @throws ElementNotFoundException
	 */
	@Operation( summary = "Filtra Cliente nel DB per dataUltimoContatto", description = "Filtra Cliente per Data Ultimo Contatto")
	@ApiResponse(responseCode = "200", description = "Cliente trovato correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nella ricerca")
	@PostMapping("/data-ultimo-contatto")
	public ResponseEntity getDataUltimoContatto (@RequestBody GetDataUltimoContattoBetweenDto dto, Pageable page) throws ElementNotFoundException{
		List<Cliente> c = cs.getDataUltimoContattoBetween(dto, page);
		if(c==null) {
			return new ResponseEntity("Cliente non trovato", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(c);
}
	/**
	 * Filtra clienti per dataInserimento
	 * @param dto
	 * @param page
	 * @return
	 * @throws ElementNotFoundException
	 */
	@Operation( summary = "Filtra Cliente nel DB per data inserimento", description = "Filtra Cliente per data inserimento")
	@ApiResponse(responseCode = "200", description = "Cliente trovato correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nella ricerca")
	@PostMapping("/data-inserimento")
	public ResponseEntity getDataInserimento (@RequestBody GetDataInserimentoBetweenDto dto, Pageable page) throws ElementNotFoundException{
		List<Cliente> c = cs.getDataInserimentoBetween(dto, page);
		if(c==null) {
			return new ResponseEntity("Cliente non trovato", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(c);
}
	/**
	 * Filtra clienti perFatturatoAnnuale
	 * @param dto
	 * @param page
	 * @return
	 * @throws ElementNotFoundException
	 */
	@Operation( summary = "Filtra Cliente nel DB per fatturato annuale", description = "Filtra  Cliente per fatturato annuale")
	@ApiResponse(responseCode = "200", description = "Cliente trovato correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nella ricerca")
	@PostMapping("/fatturato-annuale")
	public ResponseEntity getFatturatoAnnuale (@RequestBody GetFatturatoAnnualeBetweenDto dto, Pageable page) throws ElementNotFoundException{
		List<Cliente> c = cs.getFatturatoAnnualeBetween(dto, page);
		if(c==null) {
			return new ResponseEntity("Cliente non trovato", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(c);
}
}