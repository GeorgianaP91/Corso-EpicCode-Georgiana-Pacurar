package it.epicode.gestioneenergy.repository;


import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;


import it.epicode.gestioneenergy.model.Cliente;

public interface ClienteRepository extends PagingAndSortingRepository<Cliente, String> {

	

	
	List<Cliente> findAllByOrderByNomeContattoDesc();
	List<Cliente> findAllByOrderByFatturatoAnnualeDesc();
	List<Cliente> findAllByOrderByDataInserimentoDesc();
	List<Cliente> findAllByOrderByDataUltimoContattoDesc();
	
	List<Cliente> findByNomeContattoContaining(String nomeContatto, Pageable page);
	List<Cliente> findByFatturatoAnnualeBetween (double fatturatoAnnualeDa, double fatturatoAnnualeA, Pageable page);
	List<Cliente> findByDataInserimentoBetween (String dataInserimentoDa, String dataInserimentoA, Pageable page);
	List<Cliente> findByDataUltimoContattoBetween (String dataUltimoContattoDa, String dataUltimoContattoA, Pageable page);
}
