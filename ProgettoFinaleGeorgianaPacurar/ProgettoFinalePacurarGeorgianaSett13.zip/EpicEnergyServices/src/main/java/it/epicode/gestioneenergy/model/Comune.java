package it.epicode.gestioneenergy.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

/*
 * Classe che controlla l'entity comune
 * @author Pacurar Georgiana
 */

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Slf4j
@Builder
public class Comune {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
	//@NotBlank(message = "Il cap del comune è obbligatorio")

	private String cap;
	//@NotBlank(message = "Il nome del comune è obbligatorio")

	private String nome;
	@ManyToOne
	@ToString.Exclude
	@EqualsAndHashCode.Exclude
	@JsonIgnore
	private Provincia provincia;
	@OneToMany (mappedBy = "comuneSL", cascade = {CascadeType.ALL})
	@ToString.Exclude
	@EqualsAndHashCode.Exclude
	@JsonIgnore
	private List<IndirizzoSedeLegale> indSediLeg = new ArrayList<IndirizzoSedeLegale>();
	@OneToMany(mappedBy = "comuneSO", cascade = {CascadeType.ALL})
	@ToString.Exclude
	@EqualsAndHashCode.Exclude
	@JsonIgnore
	private List<IndirizzoSedeOperativa> indSediOpe = new ArrayList<IndirizzoSedeOperativa>();
}
