package it.epicode.gestioneenergy.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import it.epicode.gestioneenergy.dto.ComuneDto;
import it.epicode.gestioneenergy.dto.IndirizzoSedeLegaleDto;
import it.epicode.gestioneenergy.errors.ElementAlreadyPresentException;
import it.epicode.gestioneenergy.errors.ElementNotFoundException;
import it.epicode.gestioneenergy.model.Comune;
import it.epicode.gestioneenergy.model.IndirizzoSedeLegale;
import it.epicode.gestioneenergy.services.ComuneService;
import it.epicode.gestioneenergy.services.IndirizzoSedeLegaleService;

/**
 * 
 * @author Georgiana Pacurar
 * Servizi REST relativi alla classe IndirizzosedeLegale
 * 
 */
@RestController
@RequestMapping("/indirizzosedelegale")
@Tag(name = "IndirizzoSedeLegale rest servicies", description = "implementazioni delle api rest dell'IndirizzoSedeLegale")
public class IndirizzoSedeLegaleController {
	
	@Autowired
	IndirizzoSedeLegaleService ls;

	/**
	 * Inserisce un IndirizzoSedeLegale nel db
	 * @param dto
	 * @return
	 * @throws ElementAlreadyPresentException
	 */
	@Operation( summary = "Inserisce un IndirizzoSedeLegale nel DB", description = "Inserimento di un IndirizzoSedeLegale")
	@ApiResponse(responseCode = "200", description = "Indirizzo Sede Legale inserito correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nell'inserimento")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@PostMapping("/")
	public ResponseEntity inserisciIndirizzoSedeLegale (@RequestBody @Valid IndirizzoSedeLegaleDto dto) throws ElementAlreadyPresentException {
		ls.inserisciIndirizzoSedeLegale(dto);
		return ResponseEntity.ok("IndirizzoSedeLegale inserito");
}
	/**
	 * 
	 * Elimina un IndirizzoSedeLegale da un db
	 * @param id
	 * @return
	 * @throws ElementNotFoundException
	 */
	@Operation( summary = "Elimina un IndirizzoSedeLegale nel DB", description = "Eliminazione di un IndirizzoSedeLegale per id")
	@ApiResponse(responseCode = "200", description = "IndirizzoSedeLegale eliminato correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nell'eliminazione")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@DeleteMapping("/eliminaindirizzosedelegale/{id}")
	public ResponseEntity eliminaIndirizzoSedeLegale(@PathVariable("id") int id_IndirizzoSedeLegale)throws ElementNotFoundException {
		boolean okFindIt = ls.eliminaIndirizzoSedeLegale(id_IndirizzoSedeLegale);
		if(okFindIt) {
		return ResponseEntity.ok("Indirizzo Sede Legale Eliminato");
		} return new ResponseEntity("Indirizzo Sede Legale non trovato", HttpStatus.NOT_FOUND);
}
	/**
	 * Modifica gli attributi di un IndirizzoSedeLegale
	 * @param id
	 * @param dto
	 * @return
	 * @throws ElementNotFoundException
	 */
	@Operation( summary = "Modifica un IndirizzoSedeLegale nel DB", description = "Modifica di un IndirizzoSedeLegale cercandolo per id")
	@ApiResponse(responseCode = "200", description = "IndirizzoSedeLegale modificato correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nella modifica")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@PutMapping("/modificaindirizzosedelegale{id}")
	public ResponseEntity modificaIndirizzoSedeLegale (@PathVariable("id") int id_IndirizzoSedeLegale, @Valid @RequestBody IndirizzoSedeLegaleDto dto) throws ElementNotFoundException{
		boolean bb = ls.modificaIndirizzoSedeLegale(dto, id_IndirizzoSedeLegale);
		if(bb) {
			return ResponseEntity.ok("IndirizzoSedeLegale Modificato con successo");
			
		}return new ResponseEntity("IndirizzoSedeLegale non esistente o non trovato!", HttpStatus.NOT_FOUND);
	}
	/**
	 * Ricerca una lista di IndirizziSedeLegale
	 * @return
	 */
	@Operation( summary = "Ricerca una lista di IndirizziSedeLegale nel DB", description = "Ricerca di una lista di IndirizziSedeLegale")
	@ApiResponse(responseCode = "200", description = "Indirizzi Sede Legale trovati correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nella ricerca")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/mostraindirizzisedelegale")
	public ResponseEntity mostraTuttiIndirizzoSedeLegale () {
		return ResponseEntity.ok(ls.mostraTuttiIndirizzi());
	}
	/**
	 * Ricerca un IndirizzoSedeLegale tramite id
	 * @param id
	 * @return
	 */
	@Operation( summary = "Ricerca un IndirizzoSedeLegale nel DB per id", description = "Ricerca di un IndirizzoSedeLegale")
	@ApiResponse(responseCode = "200", description = "Indirizzo Sede Legale trovato correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nella ricerca")
	@GetMapping("/{id}")
	public ResponseEntity cercaIndirizzoSedeLegalePerId(@PathVariable("id")int id_IndirizzoSedeLegale) {
		IndirizzoSedeLegale isl = ls.cercaPerId(id_IndirizzoSedeLegale);
		if(isl == null) {
			return new ResponseEntity("Indirizzo sede Legale non trovato", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(isl);
}
}
