package it.epicode.gestioneenergy.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

/**
 * Classe che gestisce l'entity indirizzoSedeLegale
 * @author Pacurar Georgiana
 */

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Slf4j
@Builder
public class IndirizzoSedeLegale {

	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int id;
	//@NotBlank(message = "La via dell'indirizzo della sede legale è obbligatoria")
	//@Size(min = 20, max = 50, message = "Deve essere di min 20 caratteri e max 50 caratteri")
	private String via;
	//@NotBlank(message = "Il civico dell'indirizzo della sede legale è obbligatorio")
	//@Size(min = 1, max = 5, message = "Deve essere di min 1 caratteri e max 5 caratteri")
	private int civico;
	//@NotBlank(message = "La località dell'indirizzo della sede legale è obbligatoria")
	//@Size(min = 20, max = 50, message = "Deve essere di min 20 caratteri e max 50 caratteri")
	private String localita;
	//@NotBlank(message = "Il cap dell'indirizzo della sede legale è obbligatorio")
	//@Size(min = 4, max = 5, message = "Deve essere di min 4 caratteri e max 5 caratteri")
	private String cap;
	@OneToOne(mappedBy = "indsl")
	@ToString.Exclude
	@EqualsAndHashCode.Exclude
	@JsonIgnore
	private Cliente cliente;
	@ManyToOne(cascade = {CascadeType.MERGE, CascadeType.PERSIST})
	private Comune comuneSL;

}
