package it.epicode.gestioneenergy.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import it.epicode.gestioneenergy.model.Cliente;

import it.epicode.gestioneenergy.model.Fattura;
import it.epicode.gestioneenergy.model.IndirizzoSedeLegale;
import it.epicode.gestioneenergy.model.IndirizzoSedeOperativa;

import it.epicode.gestioneenergy.model.RagioneSociale;
import it.epicode.gestioneenergy.model.StatoFattura;
import it.epicode.gestioneenergy.repository.ClienteRepository;

import it.epicode.gestioneenergy.repository.FatturaRepository;
import it.epicode.gestioneenergy.repository.IndirizzoSedeLegaleRepository;
import it.epicode.gestioneenergy.repository.IndirizzoSedeOperativaRepository;

import lombok.extern.slf4j.Slf4j;
@Component
@Slf4j
public class GestioneRunner implements CommandLineRunner {

	@Autowired
	FatturaRepository fr;
	@Autowired
	ClienteRepository cr;
	@Autowired
	IndirizzoSedeLegaleRepository indlr;
	@Autowired
	IndirizzoSedeOperativaRepository indor;

	
	@Override
	public void run(String... args) throws Exception {
	
		Cliente c = Cliente.builder().cognomeContatto("Pacurar").dataInserimento("2022-04-23").dataUltimoContatto("2022-05-15").emailContatto("georgiana@gmail.com").fatturatoAnnuale(5000).nomeContatto("Georgiana").partitaIva("1234").telefonoContatto("3456758493").pec("345").ragioneSociale(RagioneSociale.PA).telefono("06338978").build();
        Cliente c1 = Cliente.builder().cognomeContatto("Lozito").dataInserimento("2021-02-20").dataUltimoContatto("2022-05-10").emailContatto("lozitor@gmail.com").fatturatoAnnuale(9000).nomeContatto("Rosalia").partitaIva("5678").telefonoContatto("3456789044").pec("123").ragioneSociale(RagioneSociale.SAS).telefono("06889765").build();
        Cliente c2 = Cliente.builder().cognomeContatto("Monti").dataInserimento("2018-03-18").dataUltimoContatto("2019-04-12").emailContatto("matilde@gmail.com").fatturatoAnnuale(6000).nomeContatto("Matilde").partitaIva("6785").telefonoContatto("347897658").pec("987").ragioneSociale(RagioneSociale.SRL).telefono("06786549").build();
	
	    Fattura f = Fattura.builder().anno(2020).data("2020-04-10").importo(8000).numero(1).stato(StatoFattura.NON_PAGATO).build();
	    Fattura f1 = Fattura.builder().anno(2018).data("2019-02-11").importo(10000).numero(2).stato(StatoFattura.PAGATO).build();
	    Fattura f2 = Fattura.builder().anno(2019).data("2018-06-19").importo(15000).numero(3).stato(StatoFattura.IN_CORSO).build();

	    IndirizzoSedeLegale isl = IndirizzoSedeLegale.builder().cap("00133").civico(3).id(1).via("Via Roma").localita("Roma").build();
	    IndirizzoSedeLegale isl1 = IndirizzoSedeLegale.builder().cap("00144").civico(3).id(2).via("Via Ciao").localita("Ultima").build();
	    IndirizzoSedeLegale isl2 = IndirizzoSedeLegale.builder().cap("00144").civico(3).id(3).via("Via ByeBye").localita("Prima").build();
	
	    IndirizzoSedeOperativa iso = IndirizzoSedeOperativa.builder().cap("00111").civico(2).id(1).via("Via Vera").localita("Boh").build();
	    IndirizzoSedeOperativa iso2 = IndirizzoSedeOperativa.builder().cap("00145").civico(1).id(2).via("Via Nera").localita("Boh").build();
	    IndirizzoSedeOperativa iso3 = IndirizzoSedeOperativa.builder().cap("00456").civico(3).id(3).via("Via Sera").localita("Boh").build();
	
	    cr.save(c);
	    cr.save(c1);
	    cr.save(c2);
		   
	    fr.save(f);
	    fr.save(f1);
	    fr.save(f2);
	    
	    indlr.save(isl);
	    indlr.save(isl1);
	    indlr.save(isl2);
	    
	    indor.save(iso);
	    indor.save(iso2);
	    indor.save(iso3);
	    
	}
}
