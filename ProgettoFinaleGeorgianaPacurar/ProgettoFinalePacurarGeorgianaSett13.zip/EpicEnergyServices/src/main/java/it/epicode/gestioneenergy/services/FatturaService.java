package it.epicode.gestioneenergy.services;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;


import it.epicode.gestioneenergy.dto.ClienteDto;
import it.epicode.gestioneenergy.dto.FatturaDto;
import it.epicode.gestioneenergy.dto.FindByAnnoFatturaDto;
import it.epicode.gestioneenergy.dto.FindByDataFatturaDto;
import it.epicode.gestioneenergy.dto.FindByImportoFatturaDto;
import it.epicode.gestioneenergy.dto.GetFatturatoAnnualeBetweenDto;
import it.epicode.gestioneenergy.model.Cliente;
import it.epicode.gestioneenergy.model.Fattura;
import it.epicode.gestioneenergy.model.IndirizzoSedeLegale;
import it.epicode.gestioneenergy.model.IndirizzoSedeOperativa;
import it.epicode.gestioneenergy.model.StatoFattura;
import it.epicode.gestioneenergy.repository.ClienteRepository;
import it.epicode.gestioneenergy.repository.FatturaRepository;

@Service
public class FatturaService {

	@Autowired
	FatturaRepository fr;
	@Autowired
	ClienteRepository cr;
	
	public void inserisciFattura(FatturaDto dto) {
		Fattura f = new Fattura();
        BeanUtils.copyProperties(dto, f);
		fr.save(f);
	}	
	
		public boolean eliminaFattura ( int id_fattura) {
			if(!fr.existsById(id_fattura)) {
				return false;
			}
			fr.deleteById(id_fattura);
			return true;

}
		public boolean modificaFattura (FatturaDto dto, int id_fattura) {
			if(!fr.existsById(dto.getNumero()) && cr.existsById(dto.getId_cliente())) {
				return false;
		}
			Fattura f = fr.findById(id_fattura).get();
		    BeanUtils.copyProperties(dto, f);
		    f.setNumero(id_fattura);
			fr.save(f);
			return true;
}
		public List<Fattura> mostraTutteFatture() {
			return (List<Fattura>) fr.findAll();
		}
		
		public Fattura cercaPerId (int id_fattura) {
			if(!fr.existsById(id_fattura)) {
				return null;
			}
			return fr.findById(id_fattura).get();
		}
		public List<Fattura> getClienteFatturaContaining (String cliente, Pageable page) {
			return fr.findByClienteContaining(cliente, page);
		}
		public List<Fattura> getStatoFatturaContaining (StatoFattura stato, Pageable page) {
			return fr.findByStatoContaining(stato, page);
		}
		public List<Fattura> getDataFatturaBetween (FindByDataFatturaDto d,Pageable page ){
			return fr.findByDataBetween(d.getDataDa(), d.getDataA(), page);
}
		public List<Fattura> getAnnoFatturaBetween (FindByAnnoFatturaDto a,Pageable page ){
			return fr.findByAnnoBetween(a.getAnnoDa(), a.getAnnoA(), page);
}
		public List<Fattura> getImportoFatturaBetween (FindByImportoFatturaDto i,Pageable page ){
			return fr.findByImportoBetween(i.getImportoDa(), i.getImportoA(), page);
}
}		
		
		
		
		
		
		