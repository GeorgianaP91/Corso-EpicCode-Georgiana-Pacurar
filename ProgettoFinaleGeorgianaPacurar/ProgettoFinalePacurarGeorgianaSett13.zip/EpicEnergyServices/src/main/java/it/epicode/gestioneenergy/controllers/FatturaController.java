package it.epicode.gestioneenergy.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import it.epicode.gestioneenergy.dto.FatturaDto;
import it.epicode.gestioneenergy.dto.FindByAnnoFatturaDto;
import it.epicode.gestioneenergy.dto.FindByDataFatturaDto;
import it.epicode.gestioneenergy.dto.FindByImportoFatturaDto;
import it.epicode.gestioneenergy.dto.GetDataUltimoContattoBetweenDto;
import it.epicode.gestioneenergy.errors.ElementAlreadyPresentException;
import it.epicode.gestioneenergy.errors.ElementNotFoundException;
import it.epicode.gestioneenergy.model.Cliente;
import it.epicode.gestioneenergy.model.Fattura;
import it.epicode.gestioneenergy.model.StatoFattura;
import it.epicode.gestioneenergy.services.FatturaService;

/**
 * 
 * @author Georgiana Pacurar
 * Servizi REST relativi alla classe fattura
 * 
 */
@RestController
@RequestMapping("/fattura")
@Tag(name = "Fattura rest servicies", description = "implementazioni delle api rest delle Fatture")
public class FatturaController {
	
	@Autowired
	FatturaService fs;

	/**
	 * Inserisce una fattura nel db
	 * @param dto
	 * @return
	 * @throws ElementAlreadyPresentException
	 */
	@Operation( summary = "Inserisce una fattura nel DB", description = "Inserimento di una Fattura ")
	@ApiResponse(responseCode = "200", description = "Fattura inserita correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nell'inserimento")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@PostMapping("/")
	public ResponseEntity inserisciFattura (@RequestBody @Valid FatturaDto dto) throws ElementAlreadyPresentException {
		fs.inserisciFattura(dto);
		return ResponseEntity.ok("Fattura inserita");
}
	/**
	 * 
	 * Elimina una fattura da un db
	 * @param numero
	 * @return
	 * @throws ElementNotFoundException
	 */
	@Operation( summary = "Elimina una Fattura nel DB", description = "Eliminazione di una Fattura per numero")
	@ApiResponse(responseCode = "200", description = "Fattura eliminata correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nell'eliminazione")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@DeleteMapping("/eliminafattura/{numero}")
	public ResponseEntity eliminaFattura(@PathVariable("numero") int id_fattura)throws ElementNotFoundException {
		boolean okFindIt = fs.eliminaFattura(id_fattura);
		if(okFindIt) {
		return ResponseEntity.ok("Fattura Eliminata");
		} return new ResponseEntity("Fattura non trovata", HttpStatus.NOT_FOUND);
}
	/**
	 * Modifica gli attributi di una fattura
	 * @param numero
	 * @param dto
	 * @return
	 * @throws ElementNotFoundException
	 */
	@Operation( summary = "Modifica una Fattura nel DB", description = "Modifica di una Fattura cercandolo per numero")
	@ApiResponse(responseCode = "200", description = "Fattura modificata correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nella modifica")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@PutMapping("/modificafattura/{numero}")
	public ResponseEntity modificaFattura (@PathVariable("numero") int id_fattura, @Valid @RequestBody FatturaDto dto) throws ElementNotFoundException{
		boolean bb = fs.modificaFattura(dto, id_fattura);
		if(bb) {
			return ResponseEntity.ok("Fattura Modificata con successo");
			
		}return new ResponseEntity("Fattura non esistente o non trovata!", HttpStatus.NOT_FOUND);
	}
	/**
	 * Ricerca una lista di fatture
	 * @return
	 */
	@Operation( summary = "Ricerca una lista di fatture nel DB", description = "Ricerca di una lista di fatture")
	@ApiResponse(responseCode = "200", description = "Fattura trovate correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nella ricerca")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/mostrafatture")
	public ResponseEntity mostraTutteLeFattura () {
		return ResponseEntity.ok(fs.mostraTutteFatture());
	}
	/**
	 * Ricerca una fattura tramite numero
	 * @param numero
	 * @return
	 */
	@Operation( summary = "Ricerca una Fattura nel DB per numero", description = "Ricerca di un Fattura con")
	@ApiResponse(responseCode = "200", description = "Fattura trovato correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nella ricerca")
	@GetMapping("/{numero}")
	public ResponseEntity cercaFatturaPerId(@PathVariable("numero")int id_fattura) {
		Fattura f = fs.cercaPerId(id_fattura);
		if(f == null) {
			return new ResponseEntity("Fattura non trovata", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(f);
	}
	/**
	 * Filtra Fattura per cliente
	 * @param cliente
	 * @param page
	 * @return
	 * @throws ElementNotFoundException
	 */
	@Operation( summary = "Filtra Fattura nel DB per cliente", description = "Filtra Fattura per cliente")
	@ApiResponse(responseCode = "200", description = "Fattura trovata correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nella ricerca")
	@PostMapping("/clientecontaining/{cliente}")
	public ResponseEntity getClienteFattura (@PathVariable("cliente") String cliente, Pageable page) throws ElementNotFoundException {
		List<Fattura> f = fs.getClienteFatturaContaining(cliente, page);
		if(f==null) {
			return new ResponseEntity("Cliente non trovato", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(f);
	}
	/**
	 * Filtra fattura per stato
	 * @param stato
	 * @param page
	 * @return
	 * @throws ElementNotFoundException
	 */
	@Operation( summary = "Filtra Fattura nel DB per stato", description = "Filtra Fattura per stato")
	@ApiResponse(responseCode = "200", description = "Fattura trovata correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nella ricerca")
	@PostMapping("/statocontaining/{stato}")
	public ResponseEntity getStatoFattura (@PathVariable("stato") StatoFattura stato, Pageable page) throws ElementNotFoundException {
		List<Fattura> f = fs.getStatoFatturaContaining(stato, page);
		if(f==null) {
			return new ResponseEntity("Cliente non trovato", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(f);
}
	/**
	 * 
	 *Filtra Fattura per data
	 * @param dto
	 * @param page
	 * @return
	 * @throws ElementNotFoundException
	 */
	@Operation( summary = "Filtra Fattura nel DB per data", description = "Filtra fattura per Data")
	@ApiResponse(responseCode = "200", description = "Fattura trovata correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nella ricerca")
	@PostMapping("/data-fattura")
	public ResponseEntity getDataFattura (@RequestBody FindByDataFatturaDto dto, Pageable page) throws ElementNotFoundException{
		List<Fattura> f = fs.getDataFatturaBetween(dto, page);
		if(f==null) {
			return new ResponseEntity("Fattura non trovata", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(f);
}
/**
 * Filtra fattura per anno
 * @param dto
 * @param page
 * @return
 * @throws ElementNotFoundException
 */
@Operation( summary = "Filtra Fattura nel DB per anno", description = "Filtra fattura per anno")
@ApiResponse(responseCode = "200", description = "Fattura trovata correttamente")
@ApiResponse(responseCode = "500", description = "Errore nella ricerca")
@PostMapping("/anno-fattura")
public ResponseEntity getAnnoFattura (@RequestBody FindByAnnoFatturaDto dto, Pageable page) throws ElementNotFoundException{
	List<Fattura> f = fs.getAnnoFatturaBetween(dto, page);
	if(f==null) {
		return new ResponseEntity("Fattura non trovata", HttpStatus.NOT_FOUND);
	}
	return ResponseEntity.ok(f);
}
/**
 * Filtra fattura per importo
 * @param dto
 * @param page
 * @return
 * @throws ElementNotFoundException
 */
@Operation( summary = "Filtra Fattura nel DB per importo", description = "Filtra fattura per importo")
@ApiResponse(responseCode = "200", description = "Fattura trovata correttamente")
@ApiResponse(responseCode = "500", description = "Errore nella ricerca")
@PostMapping("/importo-fattura")
public ResponseEntity getImportoFattura (@RequestBody FindByImportoFatturaDto dto, Pageable page) throws ElementNotFoundException{
	List<Fattura> f = fs.getImportoFatturaBetween(dto, page);
	if(f==null) {
		return new ResponseEntity("Fattura non trovata", HttpStatus.NOT_FOUND);
	}
	return ResponseEntity.ok(f);
}
}