package it.epicode.gestioneenergy.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class GetFatturatoAnnualeBetweenDto {

	double fatturatoAnnualeDa;
	double fatturatoAnnualeA;
}
