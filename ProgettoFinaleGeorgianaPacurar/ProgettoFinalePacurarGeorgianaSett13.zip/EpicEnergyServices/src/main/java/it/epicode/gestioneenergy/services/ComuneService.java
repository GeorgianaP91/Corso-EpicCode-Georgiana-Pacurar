package it.epicode.gestioneenergy.services;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.epicode.gestioneenergy.dto.ClienteDto;
import it.epicode.gestioneenergy.dto.ComuneDto;
import it.epicode.gestioneenergy.model.Cliente;
import it.epicode.gestioneenergy.model.Comune;
import it.epicode.gestioneenergy.model.Fattura;
import it.epicode.gestioneenergy.model.IndirizzoSedeLegale;
import it.epicode.gestioneenergy.model.IndirizzoSedeOperativa;
import it.epicode.gestioneenergy.model.Provincia;
import it.epicode.gestioneenergy.repository.ComuneRepository;
import it.epicode.gestioneenergy.repository.IndirizzoSedeLegaleRepository;
import it.epicode.gestioneenergy.repository.IndirizzoSedeOperativaRepository;
import it.epicode.gestioneenergy.repository.ProvinciaRepository;

@Service
public class ComuneService {

	@Autowired
	ProvinciaRepository pr;
	@Autowired
	ComuneRepository cr;
	@Autowired
	IndirizzoSedeLegaleRepository indlr;
	@Autowired
	IndirizzoSedeOperativaRepository indor;
	
	public void inserisciComune(ComuneDto dto) {
		Comune c = new Comune();
		Provincia p = pr.findById(dto.getSigla()).get();
		IndirizzoSedeLegale il = indlr.findById(dto.getId_indsedel()).get();
		IndirizzoSedeOperativa io = indor.findById(dto.getId_indsedeo()).get();
		c.getProvincia();
		c.getIndSediLeg().add(il);
		c.getIndSediOpe().add(io);
		BeanUtils.copyProperties(dto, c);
		cr.save(c);
	
}

	public boolean eliminaComune ( int id_comune) {
		if(!cr.existsById(id_comune)) {
			return false;
		}
		cr.deleteById(id_comune);
		return true;
}
	public boolean modificaComune (ComuneDto dto, int id_comune) {
		if(!cr.existsById(dto.getId()) && !pr.existsById(dto.getSigla())&& !indlr.existsById(dto.getId_indsedel()) && !indor.existsById(dto.getId_indsedeo())) {
			return false;
		}
		Comune c = cr.findById(id_comune).get();
		Provincia p = pr.findById(dto.getSigla()).get();
		IndirizzoSedeLegale il = indlr.findById(dto.getId_indsedel()).get();
		IndirizzoSedeOperativa io = indor.findById(dto.getId_indsedeo()).get();
		c.setProvincia(p);
		c.getIndSediLeg().add(il);
		c.getIndSediOpe().add(io);
	    p.getComuni().add(c);
	    il.setComuneSL(c);
	    io.setComuneSO(c);
	    
		BeanUtils.copyProperties(dto, c);
		c.setId(id_comune);
		cr.save(c);
		return true;
	} 
	public List<Comune> mostraTuttiComuni() {
		return (List<Comune>) cr.findAll();
	}
	public Comune cercaPerId (int id_comune) {
		if(!cr.existsById(id_comune)) {
			return null;
		}
		return cr.findById(id_comune).get();
	}
}

