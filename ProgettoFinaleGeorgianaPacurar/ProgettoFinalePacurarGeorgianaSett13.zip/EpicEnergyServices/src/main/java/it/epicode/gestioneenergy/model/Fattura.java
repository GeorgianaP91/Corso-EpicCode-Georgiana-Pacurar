package it.epicode.gestioneenergy.model;

import java.math.BigDecimal;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;
/**
 * Classe che gestisce l'entity fattura
 * @author Pacurar Gergiana
 */
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Slf4j
@Builder
public class Fattura {

	@Id
	private int numero;
	//@NotBlank(message = "L'anno della fattura è obbligatoria")
	
	private int anno;
	//@NotBlank(message = "Lo stato dell fattura è obbligatoria")
	@Enumerated(EnumType.STRING)
    private StatoFattura stato;
	//@NotBlank(message = "La data dell fattura è obbligatoria")
	
	private String data;
	//@NotBlank(message = "L'importo della fattura è obbligatoria")
    private double importo;
	@ManyToOne(cascade = {CascadeType.MERGE, CascadeType.PERSIST} )
	@ToString.Exclude
	@EqualsAndHashCode.Exclude
	@JsonIgnore
	private Cliente cliente;
	
}
