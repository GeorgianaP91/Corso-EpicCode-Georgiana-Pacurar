package it.epicode.gestioneenergy.services;


import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;


import it.epicode.gestioneenergy.dto.ClienteDto;
import it.epicode.gestioneenergy.dto.GetDataInserimentoBetweenDto;
import it.epicode.gestioneenergy.dto.GetDataUltimoContattoBetweenDto;
import it.epicode.gestioneenergy.dto.GetFatturatoAnnualeBetweenDto;
import it.epicode.gestioneenergy.model.Cliente;
import it.epicode.gestioneenergy.model.Fattura;
import it.epicode.gestioneenergy.model.IndirizzoSedeLegale;
import it.epicode.gestioneenergy.model.IndirizzoSedeOperativa;
import it.epicode.gestioneenergy.repository.ClienteRepository;
import it.epicode.gestioneenergy.repository.FatturaRepository;
import it.epicode.gestioneenergy.repository.IndirizzoSedeLegaleRepository;
import it.epicode.gestioneenergy.repository.IndirizzoSedeOperativaRepository;
import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class ClienteService {

	@Autowired
	FatturaRepository fr;
	@Autowired
	ClienteRepository cr;
	@Autowired
	IndirizzoSedeLegaleRepository indlr;
	@Autowired
	IndirizzoSedeOperativaRepository indor;
	
	public void inserisciCliente(ClienteDto dto) {
		Cliente c = new Cliente();
	    Fattura f = fr.findById(dto.getId_fattura()).get();
		IndirizzoSedeLegale il = indlr.findById(dto.getId_indsedel()).get();
		IndirizzoSedeOperativa io = indor.findById(dto.getId_indsedeo()).get();
		c.getFatture().add(f);
		c.getIndso();
		c.getIndsl();
		log.info("============ERROR=============");
		BeanUtils.copyProperties(dto, c);
		log.info(cr.findAll().toString());
		log.info(fr.findAll().toString());
		log.info(indlr.findAll().toString());
		log.info(indor.findAll().toString());
		cr.save(c);
	}	
	
	public boolean eliminaCliente ( String id_cliente) {
		if(!cr.existsById(id_cliente)) {
			return false;
		}
		cr.deleteById(id_cliente);
		return true;
	}
	public boolean modificaCliente (ClienteDto dto, String id_cliente) {
		if(!cr.existsById(dto.getPartitaIva())) { //&& !fr.existsById(dto.getId_fattura())&& !indlr.existsById(dto.getId_indsedel()) && !indor.existsById(dto.getId_indsedeo())) {
			log.info("======CLIENTE NON TROVATO======");
			return false;
		}   
		if(!fr.existsById(dto.getId_fattura()))	{
			log.info("======FATTURA NON TROVATA======");
			return false;
		}
		if(!indlr.existsById(dto.getId_indsedel())) {
			log.info("======INDIRIZZO NON TROVATO======");
			return false;
		}
		if(!indor.existsById(dto.getId_indsedeo())) {
			log.info("======INDIRIZZO NON TROVATO======");
			return false;
	}
		
    Cliente c = new Cliente();
    Fattura f = fr.findById(dto.getId_fattura()).get();
    IndirizzoSedeLegale il = indlr.findById(dto.getId_indsedel()).get();
	IndirizzoSedeOperativa io = indor.findById(dto.getId_indsedeo()).get();
	
	c.getFatture().add(f);
    c.setIndsl(il);
	c.setIndso(io);
	f.setCliente(c);
	io.setCliente(c);
	il.setCliente(c);
	BeanUtils.copyProperties(dto, c);
	c.setPartitaIva(id_cliente);
	cr.save(c);
	return true;

}
	public List<Cliente> mostraTuttiClienti() {
		return (List<Cliente>) cr.findAll();
	}
   
	public List<Cliente> getAllByOrderByNomeContatto() {
		return (List<Cliente>) cr.findAllByOrderByNomeContattoDesc();
	}

	public List<Cliente> getAllByOrderByFatturatoAnnuale() {
		return (List<Cliente>) cr.findAllByOrderByFatturatoAnnualeDesc();
	}
	
	public List<Cliente> getAllByOrderByDataInserimento() {
		return (List<Cliente>) cr.findAllByOrderByDataInserimentoDesc();
	}

	public List<Cliente> getAllByOrderByDataUltimoContatto() {
		return (List<Cliente>) cr.findAllByOrderByDataUltimoContattoDesc();
	}
	public List<Cliente> getNomeContattoContaining (String nomeContatto, Pageable page) {
		return cr.findByNomeContattoContaining(nomeContatto, page);
	}
	public List<Cliente> getFatturatoAnnualeBetween (GetFatturatoAnnualeBetweenDto f,Pageable page ){
		return cr.findByFatturatoAnnualeBetween(f.getFatturatoAnnualeDa(), f.getFatturatoAnnualeA(), page);
	}
	public List<Cliente> getDataInserimentoBetween (GetDataInserimentoBetweenDto i, Pageable page) {
		return cr.findByDataInserimentoBetween(i.getDataInserimentoDa(), i.getDataInserimentoA(), page);
		
}
	public List<Cliente> getDataUltimoContattoBetween (GetDataUltimoContattoBetweenDto u, Pageable page) {
		return cr.findByDataUltimoContattoBetween(u.getDataUltimoContattoDa(), u.getDataUltimoContattoA(), page);
}
	public Cliente cercaPerId (String id_cliente) {
		if(!cr.existsById(id_cliente)) {
			return null;
		}
		return cr.findById(id_cliente).get();
	}
}
