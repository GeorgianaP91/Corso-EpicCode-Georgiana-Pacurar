package it.epicode.gestioneenergy.repository;

import org.springframework.data.repository.PagingAndSortingRepository;

import it.epicode.gestioneenergy.model.IndirizzoSedeLegale;

public interface IndirizzoSedeLegaleRepository extends PagingAndSortingRepository<IndirizzoSedeLegale, Integer> {

}
