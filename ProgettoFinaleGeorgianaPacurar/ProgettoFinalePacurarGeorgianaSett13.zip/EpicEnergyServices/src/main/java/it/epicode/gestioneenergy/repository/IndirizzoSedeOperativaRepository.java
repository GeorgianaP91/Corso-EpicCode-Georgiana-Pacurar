package it.epicode.gestioneenergy.repository;

import org.springframework.data.repository.PagingAndSortingRepository;

import it.epicode.gestioneenergy.model.IndirizzoSedeOperativa;

public interface IndirizzoSedeOperativaRepository extends PagingAndSortingRepository<IndirizzoSedeOperativa, Integer> {

}
