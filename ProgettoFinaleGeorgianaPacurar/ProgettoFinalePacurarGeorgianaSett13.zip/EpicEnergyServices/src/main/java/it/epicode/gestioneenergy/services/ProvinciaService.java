package it.epicode.gestioneenergy.services;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.epicode.gestioneenergy.dto.FatturaDto;
import it.epicode.gestioneenergy.dto.ProvinciaDto;
import it.epicode.gestioneenergy.model.Cliente;
import it.epicode.gestioneenergy.model.Comune;
import it.epicode.gestioneenergy.model.Fattura;
import it.epicode.gestioneenergy.model.Provincia;
import it.epicode.gestioneenergy.repository.ComuneRepository;
import it.epicode.gestioneenergy.repository.ProvinciaRepository;

@Service
public class ProvinciaService {

	@Autowired
	ProvinciaRepository pr;
	@Autowired
	ComuneRepository cr;
	
	public void inserisciProvincia(ProvinciaDto dto) {
		Provincia p = new Provincia();
		Comune c = cr.findById(dto.getId_comune()).get();
		p.getComuni().add(c);
	    BeanUtils.copyProperties(dto, p);
		pr.save(p);
}

	public boolean eliminaProvincia ( String id_provincia) {
		if(!pr.existsById(id_provincia)) {
			return false;
		}
		pr.deleteById(id_provincia);
		return true;
}
	public boolean modificaProvincia (ProvinciaDto dto, String id_provincia) {
		if(!pr.existsById(dto.getSigla()) && !cr.existsById(dto.getId_comune())) {
			return false;
			}
		Provincia p = pr.findById(id_provincia).get();
		Comune c = cr.findById(dto.getId_comune()).get();
		p.getComuni().add(c);
	    BeanUtils.copyProperties(dto, p);
	    p.setSigla(id_provincia);
		pr.save(p);
		return true;
	}		
	public List<Provincia> mostraTutteProvince() {
		return (List<Provincia>) pr.findAll();
	}
	
	public Provincia cercaPerId (String id_provincia) {
		if(!pr.existsById(id_provincia)) {
			return null;
		}
		return pr.findById(id_provincia).get();
	}
}		
		