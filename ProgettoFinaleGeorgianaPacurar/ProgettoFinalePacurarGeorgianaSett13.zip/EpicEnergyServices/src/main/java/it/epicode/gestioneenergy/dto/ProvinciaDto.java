package it.epicode.gestioneenergy.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class ProvinciaDto {

	 private String id;
		private String nome;
		private String sigla;
		private String regione;
		private int id_comune;
}
