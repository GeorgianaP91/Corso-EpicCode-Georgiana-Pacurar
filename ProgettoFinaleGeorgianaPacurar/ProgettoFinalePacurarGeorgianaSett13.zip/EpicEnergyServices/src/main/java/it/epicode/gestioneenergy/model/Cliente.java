package it.epicode.gestioneenergy.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;
/**
 * Classe che gestisce l'entity cliente
 * @author Pacurar Georgiana
 */
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Slf4j
@Builder
public class Cliente {

	@Enumerated(EnumType.STRING)
	private RagioneSociale ragioneSociale;
	@Id
	private String partitaIva;
	//@NotBlank(message = "La data di inserimento del cliente è obbligatoria")

	private String dataInserimento;
	//@NotBlank(message = "La data dell'ultimo contatto del cliente è obbligatoria")
	
	private String dataUltimoContatto;
	//@NotBlank(message = "L'importo fatturato del cliente è obbligatorio")
	private double fatturatoAnnuale;
	//@NotBlank(message = "La pec del cliente è obbligatoria")
	private String pec;
	//@NotBlank(message = "Il telefono del cliente è obbligatorio")
	
	private String telefono;
	//@NotBlank(message = "L'email del cliente è obbligatoria")

	private String emailContatto;
	//@NotBlank(message = "Il nome del cliente è obbligatorio")

	private String nomeContatto;
	//@NotBlank(message = "Il cognome del cliente è obbligatorio")

	private String cognomeContatto;
	//@NotBlank(message = "Il telefono del cliente è obbligatorio")

	private String telefonoContatto;
	@OneToOne(cascade = CascadeType.ALL)
	@ToString.Exclude
    @EqualsAndHashCode.Exclude
	@JsonIgnore
	private IndirizzoSedeLegale indsl;
	@OneToOne(cascade = CascadeType.ALL)
    @ToString.Exclude
	@EqualsAndHashCode.Exclude
	@JsonIgnore
	private IndirizzoSedeOperativa indso;
	@OneToMany(mappedBy = "cliente", cascade = CascadeType.ALL)
	@ToString.Exclude
	@EqualsAndHashCode.Exclude
	@JsonIgnore
	private List<Fattura> fatture = new ArrayList<Fattura>();

}
