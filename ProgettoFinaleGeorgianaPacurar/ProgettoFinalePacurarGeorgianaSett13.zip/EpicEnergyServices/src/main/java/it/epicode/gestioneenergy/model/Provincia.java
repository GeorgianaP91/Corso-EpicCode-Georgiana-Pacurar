package it.epicode.gestioneenergy.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;
/**
 * Classe che gestisce l'entity Provincia
 * @author Pacurar Georgiana
 */
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Slf4j
@Builder
public class Provincia {

	
 
	@Id
	private String sigla;
	//@NotBlank(message = "Il nome della provincia è obbligatoria")
	//@Size(min = 4, max = 30, message = "Deve essere di min 4 caratteri e max 30 caratteri")
	private String nome;
	//@NotBlank(message = "La regione della provincia è obbligatoria")
	//@Size(min = 4, max = 30, message = "Deve essere di min 4 caratteri e max 30caratteri")
	private String regione;
	@OneToMany(mappedBy = "provincia", cascade = CascadeType.ALL)
	@ToString.Exclude
	@EqualsAndHashCode.Exclude
	@JsonIgnore
	private List<Comune> comuni = new ArrayList<Comune>();
}
