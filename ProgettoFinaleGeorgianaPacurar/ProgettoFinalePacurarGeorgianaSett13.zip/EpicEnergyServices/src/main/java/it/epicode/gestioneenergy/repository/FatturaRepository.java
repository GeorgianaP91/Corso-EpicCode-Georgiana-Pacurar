package it.epicode.gestioneenergy.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;


import it.epicode.gestioneenergy.model.Fattura;
import it.epicode.gestioneenergy.model.StatoFattura;

public interface FatturaRepository extends PagingAndSortingRepository<Fattura, Integer> {

	List<Fattura> findByClienteContaining (String cliente, Pageable page);
	List<Fattura> findByStatoContaining (StatoFattura stato, Pageable page);
	List<Fattura> findByDataBetween (String dataDa, String dataA, Pageable page);
	List<Fattura> findByAnnoBetween (int annoDa, int annoA, Pageable page);
	List<Fattura> findByImportoBetween (double importoDa, double importoA, Pageable page);
}
