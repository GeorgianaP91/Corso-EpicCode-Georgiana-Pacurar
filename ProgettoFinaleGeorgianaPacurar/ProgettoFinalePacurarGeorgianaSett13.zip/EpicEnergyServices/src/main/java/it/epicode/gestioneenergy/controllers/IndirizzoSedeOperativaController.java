package it.epicode.gestioneenergy.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import it.epicode.gestioneenergy.dto.IndirizzoSedeLegaleDto;
import it.epicode.gestioneenergy.dto.IndirizzoSedeOperativaDto;
import it.epicode.gestioneenergy.errors.ElementAlreadyPresentException;
import it.epicode.gestioneenergy.errors.ElementNotFoundException;
import it.epicode.gestioneenergy.model.IndirizzoSedeLegale;
import it.epicode.gestioneenergy.model.IndirizzoSedeOperativa;
import it.epicode.gestioneenergy.services.IndirizzoSedeLegaleService;
import it.epicode.gestioneenergy.services.IndirizzoSedeOperativaService;

/**
 * 
 * @author Georgiana Pacurar
 * Servizi REST relativi alla classe IndirizzosedeOperativa
 * 
 */
@RestController
@RequestMapping("/indirizzosedeoperativa")
@Tag(name = "IndirizzoSedeOperativa rest servicies", description = "implementazioni delle api rest dell'IndirizzoSedeOperativa")
public class IndirizzoSedeOperativaController {
	
	@Autowired
	IndirizzoSedeOperativaService os;

	/**
	 * Inserisce un IndirizzoSedeOperativa nel db
	 * @param dto
	 * @return
	 * @throws ElementAlreadyPresentException
	 */
	@Operation( summary = "Inserisce un IndirizzoSedeOperativa nel DB", description = "Inserimento di un IndirizzoSedeOperativa")
	@ApiResponse(responseCode = "200", description = "Indirizzo Sede Operativa inserito correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nell'inserimento")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@PostMapping("/")
	public ResponseEntity inserisciIndirizzoSedeOperativa (@RequestBody @Valid IndirizzoSedeOperativaDto dto) throws ElementAlreadyPresentException {
		os.inserisciIndirizzoSedeOperativa(dto);
		return ResponseEntity.ok("IndirizzoSedeOperativa inserito");
}
	/**
	 * 
	 * Elimina un IndirizzoSedeOperativa da un db
	 * @param id
	 * @return
	 * @throws ElementNotFoundException
	 */
	@Operation( summary = "Elimina un IndirizzoSedeOperativa nel DB", description = "Eliminazione di un IndirizzoSedeOperativa per id")
	@ApiResponse(responseCode = "200", description = "IndirizzoSedeOperativa eliminato correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nell'eliminazione")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@DeleteMapping("/eliminaindirizzosedeoperativa/{id}")
	public ResponseEntity eliminaIndirizzoSedeOperativa(@PathVariable("id") int id_IndirizzoSedeOperativa)throws ElementNotFoundException {
		boolean okFindIt = os.eliminaIndirizzoSedeOperativa(id_IndirizzoSedeOperativa);
		if(okFindIt) {
		return ResponseEntity.ok("Indirizzo Sede Operativa Eliminato");
		} return new ResponseEntity("Indirizzo Sede Operativa non trovato", HttpStatus.NOT_FOUND);
}
	/**
	 * Modifica gli attributi di un IndirizzoSedeOperativa
	 * @param id
	 * @param dto
	 * @return
	 * @throws ElementNotFoundException
	 */
	@Operation( summary = "Modifica un IndirizzoSedeOperativa nel DB", description = "Modifica di un IndirizzoSedeOperativa cercandolo per id")
	@ApiResponse(responseCode = "200", description = "IndirizzoSedeOperativa modificato correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nella modifica")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	@PutMapping("/modificaindirizzosedeoperativa/{id}")
	public ResponseEntity modificaIndirizzoSedeOperativa (@PathVariable("id") int id_IndirizzoSedeOperativa, @Valid @RequestBody IndirizzoSedeOperativaDto dto) throws ElementNotFoundException{
		boolean bb = os.modificaIndirizzoSedeOperativa(dto, id_IndirizzoSedeOperativa);
		if(bb) {
			return ResponseEntity.ok("IndirizzoSedeOperativa Modificato con successo");
			
		}return new ResponseEntity("IndirizzoSedeOperativa non esistente o non trovato!", HttpStatus.NOT_FOUND);
	}
	/**
	 * Ricerca una lista di IndirizziSedeOperativa
	 * @return
	 */
	@Operation( summary = "Ricerca una lista di IndirizziSedeOperativa nel DB", description = "Ricerca di una lista di IndirizziSedeOperativa")
	@ApiResponse(responseCode = "200", description = "Indirizzi Sede Operativa trovati correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nella ricerca")
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/mostraindirizzisedeoperativa")
	public ResponseEntity mostraTuttiIndirizzoSedeOperativa () {
		return ResponseEntity.ok(os.mostraTuttiIndirizzi());
	}
	/**
	 * Ricerca un IndirizzoSedeOperativa tramite id
	 * @param id
	 * @return
	 */
	@Operation( summary = "Ricerca un IndirizzoSedeOperativa nel DB per id", description = "Ricerca di un IndirizzoSedeOperativa")
	@ApiResponse(responseCode = "200", description = "Indirizzo Sede Operativa trovato correttamente")
	@ApiResponse(responseCode = "500", description = "Errore nella ricerca")
	@GetMapping("/{id}")
	public ResponseEntity cercaIndirizzoSedeOperativaPerId(@PathVariable("id")int id_IndirizzoSedeOperativa) {
		IndirizzoSedeOperativa iso = os.cercaPerId(id_IndirizzoSedeOperativa);
		if(iso == null) {
			return new ResponseEntity("Indirizzo Sede Operativa non trovato", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(iso);
}
}

