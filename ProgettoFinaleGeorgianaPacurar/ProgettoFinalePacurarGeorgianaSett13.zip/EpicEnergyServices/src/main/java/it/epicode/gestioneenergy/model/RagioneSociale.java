package it.epicode.gestioneenergy.model;
/**
 * Classe che gestisce l'enum della ragione sociale
 * @author Pacurar Georgiana
 */
public enum RagioneSociale {

	PA,
	SAS,
	SPA,
	SRL;
}
