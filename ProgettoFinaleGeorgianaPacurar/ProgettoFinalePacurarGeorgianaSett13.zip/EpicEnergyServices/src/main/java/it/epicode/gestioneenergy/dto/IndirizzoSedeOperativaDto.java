package it.epicode.gestioneenergy.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class IndirizzoSedeOperativaDto {

	private int id;
	private String via;
    private int civico;
    private String localita;
    private String cap;
    private int id_comuneSO;
    private String partitaIva;

}
