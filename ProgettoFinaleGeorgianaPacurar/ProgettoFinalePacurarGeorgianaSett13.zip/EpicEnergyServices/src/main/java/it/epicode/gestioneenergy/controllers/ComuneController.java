package it.epicode.gestioneenergy.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import it.epicode.gestioneenergy.dto.ClienteDto;
import it.epicode.gestioneenergy.dto.ComuneDto;
import it.epicode.gestioneenergy.errors.ElementAlreadyPresentException;
import it.epicode.gestioneenergy.errors.ElementNotFoundException;
import it.epicode.gestioneenergy.model.Cliente;
import it.epicode.gestioneenergy.model.Comune;
import it.epicode.gestioneenergy.services.ClienteService;
import it.epicode.gestioneenergy.services.ComuneService;


	/**
	 * 
	 * @author Georgiana Pacurar
	 * Servizi REST relativi alla classe comune
	 * 
	 */
	@RestController
	@RequestMapping("/comune")
	@Tag(name = "Comune rest servicies", description = "implementazioni delle api rest dei Comuni")
	public class ComuneController {
		
		@Autowired
		ComuneService cs;

		/**
		 * Inserisce un comune nel db
		 * @param dto
		 * @return
		 * @throws ElementAlreadyPresentException
		 */
		@Operation( summary = "Inserisce un Comune nel DB", description = "Inserimento di un Comune con: nome, cap, provincia ")
		@ApiResponse(responseCode = "200", description = "Comune inserito correttamente")
		@ApiResponse(responseCode = "500", description = "Errore nell'inserimento")
		@SecurityRequirement(name = "bearerAuth")
		@PreAuthorize("hasRole('ADMIN')")
		@PostMapping("/")
		public ResponseEntity inserisciComune (@RequestBody @Valid ComuneDto dto) throws ElementAlreadyPresentException {
			cs.inserisciComune(dto);
			return ResponseEntity.ok("Comune inserito");
	}
		/**
		 * 
		 * Elimina un comune da un db
		 * @param id_comune
		 * @return
		 * @throws ElementNotFoundException
		 */
		@Operation( summary = "Elimina un Comune nel DB", description = "Eliminazione di un Comune per id")
		@ApiResponse(responseCode = "200", description = "Comune eliminato correttamente")
		@ApiResponse(responseCode = "500", description = "Errore nell'eliminazione")
		@SecurityRequirement(name = "bearerAuth")
		@PreAuthorize("hasRole('ADMIN')")
		@DeleteMapping("/eliminacomune/{id}")
		public ResponseEntity eliminaComune(@PathVariable("id") int id_comune)throws ElementNotFoundException {
			boolean okFindIt = cs.eliminaComune(id_comune);
			if(okFindIt) {
			return ResponseEntity.ok("Comune Eliminato");
			} return new ResponseEntity("Comune non trovato", HttpStatus.NOT_FOUND);
	}
		/**
		 * Modifica gli attributi di un comune
		 * @param id
		 * @param dto
		 * @return
		 * @throws ElementNotFoundException
		 */
		@Operation( summary = "Modifica un Comune nel DB", description = "Modifica di un Comune cercandolo per id")
		@ApiResponse(responseCode = "200", description = "Comune modificato correttamente")
		@ApiResponse(responseCode = "500", description = "Errore nella modifica")
		@SecurityRequirement(name = "bearerAuth")
		@PreAuthorize("hasRole('ADMIN')")
		@PutMapping("/modificacomune/{id}")
		public ResponseEntity modificaComune (@PathVariable("id") int id_comune, @Valid @RequestBody ComuneDto dto) throws ElementNotFoundException{
			boolean bb = cs.modificaComune(dto, id_comune);
			if(bb) {
				return ResponseEntity.ok("Comune Modificato con successo");
				
			}return new ResponseEntity("Comune non esistente o non trovato!", HttpStatus.NOT_FOUND);
		}
		/**
		 * Ricerca una lista di comuni
		 * @return
		 */
		@Operation( summary = "Ricerca una lista di comuni nel DB", description = "Ricerca di una lista di comuni con:  nome, cap, provincia ")
		@ApiResponse(responseCode = "200", description = "Comuni trovati correttamente")
		@ApiResponse(responseCode = "500", description = "Errore nella ricerca")
		@SecurityRequirement(name = "bearerAuth")
		@PreAuthorize("isAuthenticated()")
		@GetMapping("/mostracomuni")
		public ResponseEntity mostraTuttiComuni () {
			return ResponseEntity.ok(cs.mostraTuttiComuni());
		}
		/**
		 * Ricerca un comune tramite id
		 * @param id
		 * @return
		 */
		@Operation( summary = "Ricerca un Comune nel DB per id", description = "Ricerca di un Comune con: nome, cap, provincia")
		@ApiResponse(responseCode = "200", description = "Comune trovato correttamente")
		@ApiResponse(responseCode = "500", description = "Errore nella ricerca")
		@GetMapping("/{id}")
		public ResponseEntity cercaComunePerId(@PathVariable("partitaIva")int id_comune) {
			Comune c = cs.cercaPerId(id_comune);
			if(c == null) {
				return new ResponseEntity("Comune non trovato", HttpStatus.NOT_FOUND);
			}
			return ResponseEntity.ok(c);
}
}