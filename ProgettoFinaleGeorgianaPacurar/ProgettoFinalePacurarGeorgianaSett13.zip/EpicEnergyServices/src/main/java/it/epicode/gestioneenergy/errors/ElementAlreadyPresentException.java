package it.epicode.gestioneenergy.errors;

public class ElementAlreadyPresentException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ElementAlreadyPresentException(String message) {
		super(message);
	}
}

