package it.epicode.gestioneenergy.dto;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;

import it.epicode.gestioneenergy.model.RagioneSociale;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class ClienteDto {

	
	private String partitaIva;
	@Enumerated(EnumType.STRING)
	private RagioneSociale ragioneSociale;
	private String dataInserimento;
	private String dataUltimoContatto;
	private double fatturatoAnnuale;
	private String pec;
	private String telefono;
	private String emailContatto;
	private String nomeContatto;
	private String cognomeContatto;
	private String telefonoContatto;
	private int id_indsedeo;
	private int id_indsedel;
	private int id_fattura;
}
