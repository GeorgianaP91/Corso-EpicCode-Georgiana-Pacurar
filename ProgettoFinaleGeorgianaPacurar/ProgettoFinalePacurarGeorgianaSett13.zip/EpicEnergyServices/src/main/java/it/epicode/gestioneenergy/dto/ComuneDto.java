package it.epicode.gestioneenergy.dto;

import java.math.BigDecimal;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class ComuneDto {

	    private int id;
		private String nome;
		private String sigla;
		private int id_indsedeo;
		private int id_indsedel;
		private String cap;
}
