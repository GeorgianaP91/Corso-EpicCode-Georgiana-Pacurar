package it.epicode.gestioneenergy.test;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import it.epicode.gestioneenergy.dto.ComuneDto;
import it.epicode.gestioneenergy.dto.IndirizzoSedeLegaleDto;
import it.epicode.gestioneenergy.impl.LoginRequest;
import lombok.extern.slf4j.Slf4j;


@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Slf4j
public class IndirizzoSedeLegaleTest {
	
	@Autowired
	TestRestTemplate trt;
	@LocalServerPort int port;
	
	protected String getAdminToken() {
		String url = "http://localhost:" + port + "/api/auth/login/jwt";
		LoginRequest login = new LoginRequest();
		login.setUserName("Georgiana");
		login.setPassword("patata");
		HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login);
		String jwt = trt.postForObject(url, loginRequest, String.class);
		return jwt;
	}
	
	protected String getUserToken() {
		String url = "http://localhost:" + port + "/api/auth/login/jwt";
		LoginRequest login = new LoginRequest();
		login.setUserName("Ospite");
		login.setPassword("ospite");
		HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login);
		String jwt = trt.postForObject(url, loginRequest, String.class);
		return jwt;
	}
	
	protected HttpHeaders getAdminHeader() {
		HttpHeaders header = new HttpHeaders();
		String jwt = getAdminToken();
		log.info("---------VERIFICA JWT-----------" + jwt);
		header.set("Authorization", "Bearer " + jwt);
		return header;
	}
	
	protected HttpHeaders getUserHeader() {
		HttpHeaders header = new HttpHeaders();
		String jwt = getUserToken();
		header.set("Authorization", "Bearer " + jwt);
		return header;
	}
	
	@Test
	void inserisciIndirizzoSedeLegale() {
	String url = "http://localhost:" + port + "/indirizzosedelegale/";
	IndirizzoSedeLegaleDto dto = new IndirizzoSedeLegaleDto();
	dto.setCap("9876");
	dto.setCivico(7);
	dto.setId_comuneSL(567);
	dto.setVia("Via Fiuggi");
	dto.setPartitaIva("hhjg");
	dto.setLocalita("Fiuggi");
	

	HttpEntity<IndirizzoSedeLegaleDto> IndirizzoSedeLegaleEntity = new HttpEntity<IndirizzoSedeLegaleDto>(dto);
	log.info("----------------IndirizzoSedeLegale-dto-----------------" + url);
	ResponseEntity<String> patata = trt.exchange(url, HttpMethod.POST, IndirizzoSedeLegaleEntity, String.class);
	assertThat(patata.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	HttpEntity<IndirizzoSedeLegaleDto> IndirizzoSedeLegaleAdmin = new HttpEntity<IndirizzoSedeLegaleDto>(dto, getAdminHeader());
	log.info("----------------IndirizzoSedeLegale-dto-----------------" + url);
	ResponseEntity<String> patata2 = trt.exchange(url, HttpMethod.POST, IndirizzoSedeLegaleAdmin, String.class);
	log.info("---------------patata2----------" + patata2);
	assertThat(patata2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	HttpEntity<IndirizzoSedeLegaleDto> IndirizzoSedeLegaleUser = new HttpEntity<IndirizzoSedeLegaleDto>(dto, getUserHeader());
	log.info("----------------IndirizzoSedeLegale-dto-----------------" + url);
	ResponseEntity<String> patata3 = trt.exchange(url, HttpMethod.POST, IndirizzoSedeLegaleUser, String.class);
	assertThat(patata3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	
	@Test
	void modificaIndirizzoSedeLegale() {
	String url = "http://localhost:" + port + "/indirizzosedelegale/modificaindirizzosedelegale/1";
	IndirizzoSedeLegaleDto dto = new IndirizzoSedeLegaleDto();
	dto.setCap("0012");
	dto.setCivico(6);
	dto.setId_comuneSL(2);
	dto.setVia("Via Anagnai");
	dto.setPartitaIva("5678");
	dto.setLocalita("Anagni");
	HttpEntity<IndirizzoSedeLegaleDto> IndirizzoSedeLegaleEntity = new HttpEntity<IndirizzoSedeLegaleDto>(dto);
	log.info("----------------IndirizzoSedeLegale-dto-----------------" + url);
	ResponseEntity<String> patata = trt.exchange(url, HttpMethod.PUT, IndirizzoSedeLegaleEntity, String.class);
	log.info("---------------patata---------" + patata);
	assertThat(patata.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	HttpEntity<IndirizzoSedeLegaleDto> IndirizzoSedeLegaleAdmin = new HttpEntity<IndirizzoSedeLegaleDto>(dto, getAdminHeader());
	log.info("----------------IndirizzoSedeLegale-dto-----------------" + url);
	ResponseEntity<String> patata2 = trt.exchange(url, HttpMethod.PUT, IndirizzoSedeLegaleAdmin, String.class);
	assertThat(patata2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	log.info("--------patata2 modifica------" + patata2);
	HttpEntity<IndirizzoSedeLegaleDto> IndirizzoSedeLegaleUser = new HttpEntity<IndirizzoSedeLegaleDto>(dto, getUserHeader());
	log.info("----------------cIndirizzoSedeLegale-dto-----------------" + url);
	ResponseEntity<String> patata3 = trt.exchange(url, HttpMethod.PUT, IndirizzoSedeLegaleUser, String.class);
	assertThat(patata3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
}
	@Test
	void CancellaIndirizzoSedeLegale() {
		String url = "http://localhost:" + port + "/indirizzosedelegale/eliminaindirizzosedelegale/2";
		ResponseEntity<String> response = trt.exchange(url, HttpMethod.DELETE, HttpEntity.EMPTY, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
		HttpEntity<String> IndirizzoSedeLegaleAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.DELETE, IndirizzoSedeLegaleAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
		HttpEntity<String> IndirizzoSedeLegaleUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.DELETE, IndirizzoSedeLegaleUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void GetTuttiIndirizzoSedeLegale() {
		String url = "http://localhost:" + port + "/indirizzosedelegale/mostraindirizzisedelegale";
		ResponseEntity<String> response = trt.getForEntity(url, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
		HttpEntity<String> IndirizzoSedeLegaleAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.GET, IndirizzoSedeLegaleAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
		HttpEntity<String> IndirizzoSedeLegaleUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.GET, IndirizzoSedeLegaleUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
	}
}