package it.epicode.gestioneenergy.test;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import it.epicode.gestioneenergy.dto.ComuneDto;
import it.epicode.gestioneenergy.dto.FatturaDto;
import it.epicode.gestioneenergy.impl.LoginRequest;
import it.epicode.gestioneenergy.model.StatoFattura;
import lombok.extern.slf4j.Slf4j;



@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Slf4j
public class FatturaTest {
	
	@Autowired
	TestRestTemplate trt;
	@LocalServerPort int port;
	
	protected String getAdminToken() {
		String url = "http://localhost:" + port + "/api/auth/login/jwt";
		LoginRequest login = new LoginRequest();
		login.setUserName("Georgiana");
		login.setPassword("patata");
		HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login);
		String jwt = trt.postForObject(url, loginRequest, String.class);
		return jwt;
	}
	
	protected String getUserToken() {
		String url = "http://localhost:" + port + "/api/auth/login/jwt";
		LoginRequest login = new LoginRequest();
		login.setUserName("Ospite");
		login.setPassword("ospite");
		HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login);
		String jwt = trt.postForObject(url, loginRequest, String.class);
		return jwt;
	}
	
	protected HttpHeaders getAdminHeader() {
		HttpHeaders header = new HttpHeaders();
		String jwt = getAdminToken();
		log.info("---------VERIFICA JWT-----------" + jwt);
		header.set("Authorization", "Bearer " + jwt);
		return header;
	}
	
	protected HttpHeaders getUserHeader() {
		HttpHeaders header = new HttpHeaders();
		String jwt = getUserToken();
		header.set("Authorization", "Bearer " + jwt);
		return header;
	}
	
	@Test
	void inserisciFattura() {
	String url = "http://localhost:" + port + "/fattura/";
	FatturaDto dto = new FatturaDto();
	dto.setAnno(2022);
	dto.setData("2000-04-13");
	dto.setImporto(5000);
	dto.setId_cliente("345GD6");
	dto.setNumero(5);
	dto.setStato(StatoFattura.PAGATO);
	
	

	HttpEntity<FatturaDto> fatturaEntity = new HttpEntity<FatturaDto>(dto);
	log.info("----------------cliente-dto-----------------" + url);
	ResponseEntity<String> patata = trt.exchange(url, HttpMethod.POST, fatturaEntity, String.class);
	assertThat(patata.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	HttpEntity<FatturaDto> clienteAdmin = new HttpEntity<FatturaDto>(dto, getAdminHeader());
	log.info("----------------cliente-dto-----------------" + url);
	ResponseEntity<String> patata2 = trt.exchange(url, HttpMethod.POST, clienteAdmin, String.class);
	log.info("---------------patata2----------" + patata2);
	assertThat(patata2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	HttpEntity<FatturaDto> clienteUser = new HttpEntity<FatturaDto>(dto, getUserHeader());
	log.info("----------------cliente-dto-----------------" + url);
	ResponseEntity<String> patata3 = trt.exchange(url, HttpMethod.POST, clienteUser, String.class);
	assertThat(patata3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	
	@Test
	void modificaFattura() {
	String url = "http://localhost:" + port + "/fattura/modificafattura/1";
	FatturaDto dto = new FatturaDto();

	dto.setAnno(2022);
	dto.setData("2000-04-13");
	dto.setImporto(5000);
	dto.setId_cliente("345GD6");
	dto.setNumero(1);
	dto.setStato(StatoFattura.PAGATO);
	
	HttpEntity<FatturaDto> fatturaEntity = new HttpEntity<FatturaDto>(dto);
	log.info("----------------comune-dto-----------------" + url);
	ResponseEntity<String> patata = trt.exchange(url, HttpMethod.PUT, fatturaEntity, String.class);
	log.info("---------------patata---------" + patata);
	assertThat(patata.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	HttpEntity<FatturaDto> clienteAdmin = new HttpEntity<FatturaDto>(dto, getAdminHeader());
	log.info("----------------comune-dto-----------------" + url);
	ResponseEntity<String> patata2 = trt.exchange(url, HttpMethod.PUT, clienteAdmin, String.class);
	assertThat(patata2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	log.info("--------patata2 modifica------" + patata2);
	HttpEntity<FatturaDto> clienteUser = new HttpEntity<FatturaDto>(dto, getUserHeader());
	log.info("----------------comune-dto-----------------" + url);
	ResponseEntity<String> patata3 = trt.exchange(url, HttpMethod.PUT, clienteUser, String.class);
	assertThat(patata3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
}
	@Test
	void CancellaFattura() {
		String url = "http://localhost:" + port + "/fattura/eliminafattura/1";
		ResponseEntity<String> response = trt.exchange(url, HttpMethod.DELETE, HttpEntity.EMPTY, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
		HttpEntity<String> clienteAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.DELETE, clienteAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
		HttpEntity<String> clienteUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.DELETE, clienteUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
}
	@Test
	void GetTuttiFattura() {
		String url = "http://localhost:" + port + "/fattura/mostrafatture";
		ResponseEntity<String> response = trt.getForEntity(url, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
		HttpEntity<String> clienteAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.GET, clienteAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
		HttpEntity<String> clienteUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.GET, clienteUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
}
}
