package it.epicode.gestioneenergy.test;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import it.epicode.gestioneenergy.dto.ComuneDto;
import it.epicode.gestioneenergy.dto.ProvinciaDto;
import it.epicode.gestioneenergy.impl.LoginRequest;
import lombok.extern.slf4j.Slf4j;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Slf4j
public class ProvinciaTest {
	
	@Autowired
	TestRestTemplate trt;
	@LocalServerPort int port;
	
	protected String getAdminToken() {
		String url = "http://localhost:" + port + "/api/auth/login/jwt";
		LoginRequest login = new LoginRequest();
		login.setUserName("Georgiana");
		login.setPassword("patata");
		HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login);
		String jwt = trt.postForObject(url, loginRequest, String.class);
		return jwt;
	}
	
	protected String getUserToken() {
		String url = "http://localhost:" + port + "/api/auth/login/jwt";
		LoginRequest login = new LoginRequest();
		login.setUserName("Ospite");
		login.setPassword("ospite");
		HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login);
		String jwt = trt.postForObject(url, loginRequest, String.class);
		return jwt;
	}
	
	protected HttpHeaders getAdminHeader() {
		HttpHeaders header = new HttpHeaders();
		String jwt = getAdminToken();
		log.info("---------VERIFICA JWT-----------" + jwt);
		header.set("Authorization", "Bearer " + jwt);
		return header;
	}
	
	protected HttpHeaders getUserHeader() {
		HttpHeaders header = new HttpHeaders();
		String jwt = getUserToken();
		header.set("Authorization", "Bearer " + jwt);
		return header;
	}
	
	@Test
	void inserisciProvincia() {
	String url = "http://localhost:" + port + "/provincia/";
	ProvinciaDto dto = new ProvinciaDto();
	dto.setSigla("OO");
	dto.setNome("Napoli");
	dto.setRegione("Terrona");
	dto.setId_comune(10);

	

	HttpEntity<ProvinciaDto> provinciaEntity = new HttpEntity<ProvinciaDto>(dto);
	log.info("----------------provincia-dto-----------------" + url);
	ResponseEntity<String> patata = trt.exchange(url, HttpMethod.POST, provinciaEntity, String.class);
	assertThat(patata.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	HttpEntity<ProvinciaDto> provinciaAdmin = new HttpEntity<ProvinciaDto>(dto, getAdminHeader());
	log.info("----------------provincia-dto-----------------" + url);
	ResponseEntity<String> patata2 = trt.exchange(url, HttpMethod.POST, provinciaAdmin, String.class);
	log.info("---------------patata2----------" + patata2);
	assertThat(patata2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	HttpEntity<ProvinciaDto> provinciaUser = new HttpEntity<ProvinciaDto>(dto, getUserHeader());
	log.info("----------------provincia-dto-----------------" + url);
	ResponseEntity<String> patata3 = trt.exchange(url, HttpMethod.POST, provinciaUser, String.class);
	assertThat(patata3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	
	@Test
	void modificaProvincia() {
	String url = "http://localhost:" + port + "/provincia/modificaprovincia/NA";
	ProvinciaDto dto = new ProvinciaDto();
	dto.setNome("Pisa");
	dto.setSigla("KK");
	dto.setRegione("Toscana");
	dto.setId_comune(500);
	HttpEntity<ProvinciaDto> provinciaEntity = new HttpEntity<ProvinciaDto>(dto);
	log.info("----------------provincia-dto-----------------" + url);
	ResponseEntity<String> patata = trt.exchange(url, HttpMethod.PUT, provinciaEntity, String.class);
	log.info("---------------patata---------" + patata);
	assertThat(patata.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	HttpEntity<ProvinciaDto> provinciaAdmin = new HttpEntity<ProvinciaDto>(dto, getAdminHeader());
	log.info("----------------provincia-dto-----------------" + url);
	ResponseEntity<String> patata2 = trt.exchange(url, HttpMethod.PUT, provinciaAdmin, String.class);
	assertThat(patata2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	log.info("--------patata2 modifica------" + patata2);
	HttpEntity<ProvinciaDto> provinciaUser = new HttpEntity<ProvinciaDto>(dto, getUserHeader());
	log.info("----------------provincia-dto-----------------" + url);
	ResponseEntity<String> patata3 = trt.exchange(url, HttpMethod.PUT, provinciaUser, String.class);
	assertThat(patata3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
}
	@Test
	void CancellaProvincia() {
		String url = "http://localhost:" + port + "/provincia/eliminaprovincia/NA";
		ResponseEntity<String> response = trt.exchange(url, HttpMethod.DELETE, HttpEntity.EMPTY, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
		HttpEntity<String> clienteAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.DELETE, clienteAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
		HttpEntity<String> clienteUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.DELETE, clienteUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
}
	@Test
	void GetTuttiProvincia() {
		String url = "http://localhost:" + port + "/provincia/mostraprovince";
		ResponseEntity<String> response = trt.getForEntity(url, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
		HttpEntity<String> provinciaAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.GET, provinciaAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
		HttpEntity<String> provinciaUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.GET, provinciaUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
}
	@Test
	void GetProvinciaById() {
		String url = "http://localhost:" + port + "/provincia/SS";
		ResponseEntity<String> response = trt.getForEntity(url, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<String> provinciaAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.GET, provinciaAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<String> provinciaUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.GET, provinciaUser, String.class);
		log.info("////////////////////////////" +response3.toString());
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
}
}