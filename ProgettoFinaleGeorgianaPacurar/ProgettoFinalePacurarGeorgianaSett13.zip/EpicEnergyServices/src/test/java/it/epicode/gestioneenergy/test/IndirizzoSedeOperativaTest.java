package it.epicode.gestioneenergy.test;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import it.epicode.gestioneenergy.dto.IndirizzoSedeLegaleDto;
import it.epicode.gestioneenergy.dto.IndirizzoSedeOperativaDto;
import it.epicode.gestioneenergy.impl.LoginRequest;
import lombok.extern.slf4j.Slf4j;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Slf4j
public class IndirizzoSedeOperativaTest {
	
	@Autowired
	TestRestTemplate trt;
	@LocalServerPort int port;
	
	protected String getAdminToken() {
		String url = "http://localhost:" + port + "/api/auth/login/jwt";
		LoginRequest login = new LoginRequest();
		login.setUserName("Georgiana");
		login.setPassword("patata");
		HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login);
		String jwt = trt.postForObject(url, loginRequest, String.class);
		return jwt;
	}
	
	protected String getUserToken() {
		String url = "http://localhost:" + port + "/api/auth/login/jwt";
		LoginRequest login = new LoginRequest();
		login.setUserName("Ospite");
		login.setPassword("ospite");
		HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login);
		String jwt = trt.postForObject(url, loginRequest, String.class);
		return jwt;
	}
	
	protected HttpHeaders getAdminHeader() {
		HttpHeaders header = new HttpHeaders();
		String jwt = getAdminToken();
		log.info("---------VERIFICA JWT-----------" + jwt);
		header.set("Authorization", "Bearer " + jwt);
		return header;
	}
	
	protected HttpHeaders getUserHeader() {
		HttpHeaders header = new HttpHeaders();
		String jwt = getUserToken();
		header.set("Authorization", "Bearer " + jwt);
		return header;
	}
	
	@Test
	void inserisciIndirizzoSedeOperativa() {
	String url = "http://localhost:" + port + "/indirizzosedeoperativa/";
	IndirizzoSedeOperativaDto dto = new IndirizzoSedeOperativaDto();
	dto.setCap("9876");
	dto.setCivico(7);
	dto.setId_comuneSO(567);
	dto.setVia("Via Fiuggi");
	dto.setPartitaIva("hhjg");
	dto.setLocalita("Fiuggi");
	

	HttpEntity<IndirizzoSedeOperativaDto> IndirizzoSedeOperativaEntity = new HttpEntity<IndirizzoSedeOperativaDto>(dto);
	log.info("----------------IndirizzoSedeOperativa-dto-----------------" + url);
	ResponseEntity<String> patata = trt.exchange(url, HttpMethod.POST, IndirizzoSedeOperativaEntity, String.class);
	assertThat(patata.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	HttpEntity<IndirizzoSedeOperativaDto> IndirizzoSedeOperativaAdmin = new HttpEntity<IndirizzoSedeOperativaDto>(dto, getAdminHeader());
	log.info("----------------IndirizzoSedeOperativa-dto-----------------" + url);
	ResponseEntity<String> patata2 = trt.exchange(url, HttpMethod.POST, IndirizzoSedeOperativaAdmin, String.class);
	log.info("---------------patata2----------" + patata2);
	assertThat(patata2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	HttpEntity<IndirizzoSedeOperativaDto> IndirizzoSedeOperativaUser = new HttpEntity<IndirizzoSedeOperativaDto>(dto, getUserHeader());
	log.info("----------------IndirizzoSedeOperativa-dto-----------------" + url);
	ResponseEntity<String> patata3 = trt.exchange(url, HttpMethod.POST, IndirizzoSedeOperativaUser, String.class);
	assertThat(patata3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	
	@Test
	void modificaIndirizzoSedeOperativa() {
	String url = "http://localhost:" + port + "/indirizzosedeoperativa/modificaindirizzosedeoperativa/1";
	IndirizzoSedeOperativaDto dto = new IndirizzoSedeOperativaDto();
	dto.setCap("0012");
	dto.setCivico(6);
	dto.setId_comuneSO(2);
	dto.setVia("Via Anagnai");
	dto.setPartitaIva("5678");
	dto.setLocalita("Anagni");
	HttpEntity<IndirizzoSedeOperativaDto> IndirizzoSedeOperativaEntity = new HttpEntity<IndirizzoSedeOperativaDto>(dto);
	log.info("----------------IndirizzoSedeOperativa-dto-----------------" + url);
	ResponseEntity<String> patata = trt.exchange(url, HttpMethod.PUT, IndirizzoSedeOperativaEntity, String.class);
	log.info("---------------patata---------" + patata);
	assertThat(patata.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	HttpEntity<IndirizzoSedeOperativaDto> IndirizzoSedeOperativaAdmin = new HttpEntity<IndirizzoSedeOperativaDto>(dto, getAdminHeader());
	log.info("----------------IndirizzoSedeOperativa-dto-----------------" + url);
	ResponseEntity<String> patata2 = trt.exchange(url, HttpMethod.PUT, IndirizzoSedeOperativaAdmin, String.class);
	assertThat(patata2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	log.info("--------patata2 modifica------" + patata2);
	HttpEntity<IndirizzoSedeOperativaDto> IndirizzoSedeOperativaUser = new HttpEntity<IndirizzoSedeOperativaDto>(dto, getUserHeader());
	log.info("----------------cIndirizzoSedeOperativa-dto-----------------" + url);
	ResponseEntity<String> patata3 = trt.exchange(url, HttpMethod.PUT, IndirizzoSedeOperativaUser, String.class);
	assertThat(patata3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
}
	@Test
	void CancellaIndirizzoSedeOperativaDto() {
		String url = "http://localhost:" + port + "/indirizzosedeoperativa/eliminaindirizzosedeoperativa/2";
		ResponseEntity<String> response = trt.exchange(url, HttpMethod.DELETE, HttpEntity.EMPTY, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
		HttpEntity<String> IndirizzoSedeOperativaAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.DELETE, IndirizzoSedeOperativaAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
		HttpEntity<String> IndirizzoSedeOperativaUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.DELETE, IndirizzoSedeOperativaUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void GetTuttiIndirizzoSedeOperativa() {
		String url = "http://localhost:" + port + "/indirizzosedeoperativa/mostraindirizzisedeoperativa";
		ResponseEntity<String> response = trt.getForEntity(url, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
		HttpEntity<String> IndirizzoSedeOperativaAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.GET, IndirizzoSedeOperativaAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
		HttpEntity<String> IndirizzoSedeOperativaUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.GET, IndirizzoSedeOperativaUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
	}
	
	}