package it.epicode.gestioneenergy.test;



import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import it.epicode.gestioneenergy.dto.ClienteDto;
import it.epicode.gestioneenergy.impl.LoginRequest;
import it.epicode.gestioneenergy.model.Cliente;
import it.epicode.gestioneenergy.model.RagioneSociale;
import lombok.extern.slf4j.Slf4j;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Slf4j
public class ClienteTest {
	
	@Autowired
	TestRestTemplate trt;
	@LocalServerPort int port;
	
	protected String getAdminToken() {
		String url = "http://localhost:" + port + "/api/auth/login/jwt";
		LoginRequest login = new LoginRequest();
		login.setUserName("Georgiana");
		login.setPassword("patata");
		HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login);
		String jwt = trt.postForObject(url, loginRequest, String.class);
		return jwt;
	}
	
	protected String getUserToken() {
		String url = "http://localhost:" + port + "/api/auth/login/jwt";
		LoginRequest login = new LoginRequest();
		login.setUserName("Ospite");
		login.setPassword("ospite");
		HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login);
		String jwt = trt.postForObject(url, loginRequest, String.class);
		return jwt;
	}
	
	protected HttpHeaders getAdminHeader() {
		HttpHeaders header = new HttpHeaders();
		String jwt = getAdminToken();
		log.info("---------VERIFICA JWT-----------" + jwt);
		header.set("Authorization", "Bearer " + jwt);
		return header;
	}
	
	protected HttpHeaders getUserHeader() {
		HttpHeaders header = new HttpHeaders();
		String jwt = getUserToken();
		header.set("Authorization", "Bearer " + jwt);
		return header;
	}
	
	@Test
	void inserisciCliente() {
	String url = "http://localhost:" + port + "/cliente/";
	ClienteDto dto = new ClienteDto();
	dto.setNomeContatto("AnnaMaria");
	dto.setCognomeContatto("Franzoni");
	dto.setDataInserimento("15/04/2022");
	dto.setDataUltimoContatto("21/05/2022");
	dto.setFatturatoAnnuale(456.465);
	dto.setPec("anna.franz@pec.com");
	dto.setTelefono("323 64 96 323");
	dto.setEmailContatto("anna.franz@gmail.com");
	dto.setTelefonoContatto("0963572044");
	dto.setPartitaIva("163523");
	dto.setRagioneSociale(RagioneSociale.SRL);
	dto.setId_indsedel(1);
	dto.setId_indsedeo(2);
	dto.setId_fattura(1);
	HttpEntity<ClienteDto> clienteEntity = new HttpEntity<ClienteDto>(dto);
	log.info("----------------cliente-dto-----------------" + url);
	ResponseEntity<String> patata = trt.exchange(url, HttpMethod.POST, clienteEntity, String.class);
	assertThat(patata.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	HttpEntity<ClienteDto> clienteAdmin = new HttpEntity<ClienteDto>(dto, getAdminHeader());
	log.info("----------------cliente-dto-----------------" + url);
	ResponseEntity<String> patata2 = trt.exchange(url, HttpMethod.POST, clienteAdmin, String.class);
	log.info("---------------patata2----------" + patata2);
	assertThat(patata2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	HttpEntity<ClienteDto> clienteUser = new HttpEntity<ClienteDto>(dto, getUserHeader());
	log.info("----------------cliente-dto-----------------" + url);
	ResponseEntity<String> patata3 = trt.exchange(url, HttpMethod.POST, clienteUser, String.class);
	assertThat(patata3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void modificaCliente() {
	String url = "http://localhost:" + port + "/cliente/modificacliente/6785";
	ClienteDto dto = new ClienteDto();
	//Cliente c2 = Cliente.builder().partitaIva("101010").cognomeContatto("Monti").dataInserimento("2018-03-18").dataUltimoContatto("2019-04-12").emailContatto("matilde@gmail.com").fatturatoAnnuale(6000).nomeContatto("ChePalle").partitaIva("6785").telefonoContatto("347897658").pec("987").ragioneSociale(RagioneSociale.SRL).telefono("06786549").build();
	dto.setNomeContatto("Pacurar");
	dto.setCognomeContatto("Pacurar");
	dto.setDataInserimento("2022-04-23");
	dto.setDataUltimoContatto("2022-05-15");
	dto.setFatturatoAnnuale(5000);
	dto.setPec("345");
	dto.setTelefono("06338978");
	dto.setEmailContatto("georgiana@gmail.com");
	dto.setTelefonoContatto("3456758493");
	dto.setPartitaIva("6785");
	dto.setRagioneSociale(RagioneSociale.PA);
	dto.setId_fattura(1);
	dto.setId_indsedel(2);
	dto.setId_indsedeo(3);
	HttpEntity<ClienteDto> clienteEntity = new HttpEntity<ClienteDto>(dto);
	log.info("----------------cliente-dto-----------------" + url);
	ResponseEntity<String> patata = trt.exchange(url, HttpMethod.PUT, clienteEntity, String.class);
	log.info("---------------patata---------" + patata);
	assertThat(patata.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	HttpEntity<ClienteDto> clienteAdmin = new HttpEntity<ClienteDto>(dto, getAdminHeader());
	log.info("----------------cliente-dto-----------------" + url);
	ResponseEntity<String> patata2 = trt.exchange(url, HttpMethod.PUT, clienteAdmin, String.class);
	assertThat(patata2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	log.info("--------patata2 modifica------" + patata2);
	HttpEntity<ClienteDto> clienteUser = new HttpEntity<ClienteDto>(dto, getUserHeader());
	log.info("----------------cliente-dto-----------------" + url);
	ResponseEntity<String> patata3 = trt.exchange(url, HttpMethod.PUT, clienteUser, String.class);
	assertThat(patata3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
}
	@Test
	void CancellaCliente() {
		String url = "http://localhost:" + port + "/cliente/1234";
		ResponseEntity<String> response = trt.exchange(url, HttpMethod.DELETE, HttpEntity.EMPTY, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
		HttpEntity<String> clienteAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.DELETE, clienteAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
		HttpEntity<String> clienteUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.DELETE, clienteUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void GetTuttiClienti() {
		String url = "http://localhost:" + port + "/cliente/cerca";
		ResponseEntity<String> response = trt.getForEntity(url, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		
		HttpEntity<String> clienteAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.GET, clienteAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		
		HttpEntity<String> clienteUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.GET, clienteUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
		
	}
	

	
