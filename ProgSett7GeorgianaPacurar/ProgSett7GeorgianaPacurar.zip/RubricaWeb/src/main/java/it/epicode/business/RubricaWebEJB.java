package it.epicode.business;




import java.util.ArrayList;
import java.util.List;



import it.epicode.rubrica.Contatto;
import it.epicode.rubrica.NumTelefoni;
import jakarta.ejb.LocalBean;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

/**
 * Session Bean implementation class RubricaWebEJB
 */
@Stateless
@LocalBean
public class RubricaWebEJB {
	@PersistenceContext(unitName="rubricaPS")
	EntityManager em;
  
    public RubricaWebEJB() {
    	
    }
    	 public void inserisciContatto(String id, String nome, String cognome, String email, String numTelefono) {
    	     int idN = Integer.parseInt(id);
    	 Contatto c = new Contatto(idN, nome, cognome, email, numTelefono);
       	inserisciContatto(c);
    	   }
    	    
    	    
    	    public void inserisciContatto(Contatto c) {
    	    	em.persist(c);
    	        
    	    }


    	    public List<Contatto> cercaContattoPerCognome(String cognome) {
    	    	Query q = em.createNamedQuery("contatto.trova.per.cognome");
    	    	q.setParameter("cognome", cognome);
    	    	return  q.getResultList();
}

    	    public List<NumTelefoni> cercaContattoPerNumero(String numTelefono) {
    	    	Query q = em.createNamedQuery("contatto.trova.per.numTelefoni");
    	    	q.setParameter("numTelefoni", numTelefono);
    	    	return (List<NumTelefoni>) q.getResultList();
}
    	    

		public void eliminaContatto(String id, String nome, String cognome, String email, String numTelefono) {
    	   int idN = Integer.parseInt(id);
    	   Contatto c = new Contatto(idN, nome, cognome, email, numTelefono);
    	   eliminaContatto(c);
}

		public void eliminaContatto(Contatto c) {
			em.remove(  em.merge(c)  );
}

		public void modificaNumContatto(String id, String nome, String cognome, String email, String numTelefono) {
		
			int idN = Integer.parseInt(id);
			Contatto c = new Contatto(idN, nome, cognome, email, numTelefono);
			modificaNumContatto(c);
			
		}
		public void modificaNumContatto(Contatto c) {
			em.merge(c);
		}
		public Contatto visualizzaTuttiContatti() {
			Query q = em.createNamedQuery("contatto.visualizza.tutti.contatti");
			return (Contatto) q.getResultList();
		}

}
		
		
		
		
		
		
		
		
		
		
		
		
		
		