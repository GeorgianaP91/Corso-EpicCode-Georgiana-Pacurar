package it.epicode.rubrica;

import java.io.Serializable;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="numTelefono")
@NamedQuery(name="contatto.trova.per.numTelefoni", query="SELECT c from Contatto c where c.numTelefoni=:numTelefoni")

public class NumTelefoni implements Serializable{
private static final long serialVersionUID = 1L;
    
	private int Id;
	private String numTelefono;
	private Contatto contatti;

	public NumTelefoni(int id, String numTelefono, Contatto contatti) {
		Id = id;
		this.numTelefono = numTelefono;
		this.contatti = contatti;
	}



	public NumTelefoni(String numTelefono, int id) {
		this.numTelefono = numTelefono;
		this.Id = id;
	}
   
	@Id
	@Column(name="id_num_tel")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getId() {return Id;}
  //  @ManyToOne
    //@JoinColumn(name="id_contatto")
    public String getNumTelefono() {return numTelefono;}
    public Contatto getContatti() {return contatti;}
	
    public void setNumTelefono(String numTelefono) {this.numTelefono = numTelefono;}
	public void setContatti(Contatto contatti) {	this.contatti = contatti;}
	public void setId(int id) {Id = id;}
	
}
