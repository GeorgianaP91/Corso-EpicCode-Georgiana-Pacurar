package it.epicode.presentation;

import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

import it.epicode.business.RubricaWebEJB;
import it.epicode.rubrica.Contatto;

/**
 * Servlet implementation class VisualizzaTuttiContatti
 */
public class VisualizzaTuttiContatti extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 @EJB
	   RubricaWebEJB rejb; 
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VisualizzaTuttiContatti() {}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		@SuppressWarnings("unchecked")
		List<Contatto> lc = (List<Contatto>) rejb.visualizzaTuttiContatti();
		
		for(Contatto c: lc) {
			response.getWriter()
				.append("<div>")
				.append(c.getNome())
				.append(c.getCognome())
				.append(c.getEmail())
				.append("</div>");
	}
	}
}
